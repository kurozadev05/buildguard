import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const css = readFileSync("src/app/globals.css", "utf8");
const tok = (n: string) => new RegExp(`--${n}:\\s*(#[0-9A-Fa-f]{6})`).exec(css)![1].toUpperCase();
const lum = (hex: string) => { const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
const ratio = (a: string, b: string) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };

describe("brand palette", () => {
  it("uses exactly the specified colours", () => {
    const spec = { primary: "#F59E0B", "primary-dark": "#D97706", dark: "#111827", bg: "#F3F4F6", card: "#FFFFFF", text: "#1F2937", muted: "#6B7280", success: "#16A34A", warning: "#F59E0B", danger: "#DC2626", info: "#2563EB", border: "#E5E7EB" };
    for (const [k, v] of Object.entries(spec)) expect(tok(k)).toBe(v);
  });
  // WCAG AA (4.5:1 for normal text) for every text/background pair the UI actually uses.
  const pairs: [string, string, string][] = [
    ["text", "card", "body text on cards"], ["text", "bg", "body text on page"], ["muted-strong", "bg", "secondary text on page"], ["muted-strong", "card", "secondary text on cards"], ["muted", "card", "muted icon/text on white"],
    ["dark", "primary", "button text on orange"], ["dark", "primary-dark", "button hover"], ["card", "danger", "white on danger button"], ["card", "dark", "white on nav"],
    ["primary", "dark", "orange on nav"], ["success-ink", "success-tint", "success badge"], ["primary-ink", "primary-tint", "warning badge"], ["danger-ink", "danger-tint", "danger badge"], ["info-ink", "info-tint", "info badge"],
    ["info", "card", "links on white"], ["danger-ink", "card", "error text on white"], ["muted-strong", "primary-tint", "hint on tint"],
  ];
  it.each(pairs)("%s on %s ≥ 4.5:1 (%s)", (fg, bg) => { expect(ratio(tok(fg), tok(bg))).toBeGreaterThanOrEqual(4.5); });
  it("does not introduce extra accent hues beyond palette + derived tints", () => {
    const hexes = new Set([...css.matchAll(/#[0-9A-Fa-f]{6}\b/g)].map((m) => m[0].toUpperCase()));
    expect(hexes.size).toBeLessThan(45);
  });
});
