import { act, renderHook } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { useDebounced } from "@/lib/hooks";
import { can } from "@/lib/perm";
import { buildValues } from "@/components/TestFields";
import type { User } from "@/lib/types";

afterEach(() => vi.useRealTimers());
describe("useDebounced", () => {
  it("collapses rapid changes into one update after the pause", () => {
    vi.useFakeTimers(); const { result, rerender } = renderHook(({ v }) => useDebounced(v, 400), { initialProps: { v: "c" } });
    for (const v of ["co", "con", "cons", "const"]) { rerender({ v }); act(() => { vi.advanceTimersByTime(100); }); }
    expect(result.current).toBe("c"); act(() => { vi.advanceTimersByTime(400); }); expect(result.current).toBe("const");
  });
});
describe("role capabilities (mirror of backend sets)", () => {
  const u = (role: User["role"]) => ({ role }) as User;
  it("matches expected access", () => {
    expect(can(u("admin"), "admin")).toBe(true); expect(can(u("qa"), "admin")).toBe(false); expect(can(u("lab"), "test")).toBe(true); expect(can(u("lab"), "write")).toBe(false);
    expect(can(u("client"), "write")).toBe(false); expect(can(u("auditor"), "audit")).toBe(true); expect(can(u("site_engineer"), "audit")).toBe(false); expect(can(null, "any")).toBe(false);
  });
});
describe("buildValues (test form -> rules-engine payload)", () => {
  it("builds cube values and validates", () => {
    expect(buildValues("cube_compressive_strength", { age_days: "7", s1: "17", s2: "16.5", s3: "17.4" })).toMatchObject({ age_days: 7, values: { specimens_mpa: [17, 16.5, 17.4] }, errors: {} });
    expect(buildValues("cube_compressive_strength", { s1: "17", s2: "", s3: "1" }).errors.specimens).toBeTruthy();
    expect(buildValues("cube_compressive_strength", { s1: "17", s2: "18", s3: "9999" }).errors.specimens).toMatch(/too high/);
  });
  it.each([["slump", { slump_mm: "100" }, "slump_mm", 100], ["fresh_temperature", { temperature_c: "30" }, "temperature_c", 30], ["upv", { velocity_km_s: "4.2" }, "velocity_km_s", 4.2], ["rebound_hammer", { rebound_number_avg: "35" }, "rebound_number_avg", 35]] as const)("%s", (t, s, key, val) => { const r = buildValues(t, s as Record<string, string>); expect(r.errors).toEqual({}); expect(r.values[key]).toBe(val); });
  it("core needs three or more positive values", () => { expect(buildValues("core_strength", { cores: "24, 25, 26" }).values.cores_equiv_cube_mpa).toEqual([24, 25, 26]); expect(buildValues("core_strength", { cores: "24, 25" }).errors.cores).toBeTruthy(); });
});
