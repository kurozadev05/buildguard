import { render } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import axe from "axe-core";
import { describe, expect, it, vi } from "vitest";
import { LangProvider } from "@/lib/i18n";
import { ToastProvider } from "@/components/ui/overlay";
import { DataTable } from "@/components/ui/DataTable";
import { Field, Input, Select } from "@/components/ui/form";
import { Alert, Badge, Button, EmptyState, ErrorState, PageHeader, Progress, StatusBadge, TabPanel, Tabs } from "@/components/ui/ui";
import { ApiError } from "@/lib/api";

vi.mock("next/navigation", () => ({ useRouter: () => ({ push: vi.fn() }), usePathname: () => "/", useSearchParams: () => new URLSearchParams() }));
vi.mock("next/link", () => ({ default: ({ href, children, ...p }: { href: string; children: React.ReactNode }) => <a href={href} {...p}>{children}</a> }));
const wrap = (ui: React.ReactNode) => <QueryClientProvider client={new QueryClient()}><LangProvider><ToastProvider>{ui}</ToastProvider></LangProvider></QueryClientProvider>;
async function violations(ui: React.ReactNode) {
  const { container } = render(wrap(ui));
  const r = await axe.run(container, { rules: { "color-contrast": { enabled: false }, region: { enabled: false } } });   // contrast is verified from the tokens in palette.test.ts (jsdom cannot compute it)
  return r.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.html).join(" | ")}`);
}
describe("axe accessibility", () => {
  it("form fields: labels, required, hint and error are programmatically associated", async () => {
    expect(await violations(<form><Field label="Email" required error="Enter a valid email"><Input type="email" /></Field><Field label="Grade" hint="IS 456"><Select><option>M25</option></Select></Field></form>)).toEqual([]);
  });
  it("Field wires aria-describedby / aria-invalid", () => {
    const { getByLabelText } = render(wrap(<Field label="Qty" required error="Too big"><Input /></Field>)); const el = getByLabelText(/Qty/);
    expect(el).toHaveAttribute("aria-invalid", "true"); expect(el.getAttribute("aria-describedby")).toBeTruthy(); expect(el).toBeRequired();
  });
  it("status badges show icon + text, never colour alone", () => {
    const { getByText } = render(wrap(<><StatusBadge status="FLAGGED" /><StatusBadge status="VERIFIED" /></>)); expect(getByText("Flagged").querySelector("svg")).toBeTruthy(); expect(getByText("Verified").querySelector("svg")).toBeTruthy();
  });
  it("data table, tabs, alerts, progress, states", async () => {
    expect(await violations(<main><PageHeader title="Batches" actions={<Button>New</Button>} /><Alert tone="warning" title="Heads up">Text</Alert><Progress value={2} max={4} label="Samples" /><Badge tone="info">x</Badge>
      <Tabs label="Sections" value="a" onChange={() => undefined} tabs={[{ id: "a", label: "A" }, { id: "b", label: "B" }]} />
      <TabPanel id="a" value="a"><p>Panel</p></TabPanel><DataTable caption="Batches" rowKey={(r: { id: string }) => r.id} href={(r) => `/b/${r.id}`} rows={[{ id: "1" }]} columns={[{ key: "c", header: "Code", cell: () => "CON-1" }]} />
      <EmptyState title="Nothing" hint="Add one" /><ErrorState error={new ApiError(500, "X", "x", "server", [], "rid")} onRetry={() => undefined} /></main>)).toEqual([]);
  });
  it("ErrorState hides raw server text and shows a reference id", () => {
    const { container } = render(wrap(<ErrorState error={new ApiError(500, "X", "psycopg2.OperationalError secret", "server", [], "rid9")} />)); expect(container.textContent).not.toContain("psycopg2"); expect(container.textContent).toContain("rid9");
  });
});
