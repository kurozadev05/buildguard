import { beforeEach, describe, expect, it, vi } from "vitest";
import { ApiError } from "@/lib/api";
import { MemoryStore, setStoreForTests } from "@/lib/offline/store";
import { discard, enqueue, flushQueue, listQueue, submitOrQueue } from "@/lib/offline/queue";
import { loadSnapshot, saveSnapshot, setSnapshotOwner, clearOfflineData } from "@/lib/offline/snapshots";

const apiMock = vi.hoisted(() => vi.fn());
vi.mock("@/lib/api", async (orig) => ({ ...(await orig<typeof import("@/lib/api")>()), api: apiMock }));
beforeEach(() => { setStoreForTests(new MemoryStore()); apiMock.mockReset(); Object.defineProperty(navigator, "onLine", { value: true, configurable: true }); });

describe("offline queue", () => {
  it("removes an operation only after the server confirms it", async () => {
    const a = await enqueue("u1", "batch.create", { id: "b1" }, "A"); const b = await enqueue("u1", "sample.create", { id: "s1" }, "B");
    apiMock.mockResolvedValue({ results: [{ op_id: a.op_id, status: "applied" }, { op_id: b.op_id, status: "rejected", error: "Batch not found" }], applied: 1, duplicates: 0, rejected: 1 });
    const s = await flushQueue("u1"); expect(s).toMatchObject({ applied: 1, failed: 1 });
    const left = await listQueue("u1"); expect(left).toHaveLength(1); expect(left[0]).toMatchObject({ status: "failed", error: "Batch not found" });
  });
  it("treats server 'duplicate' as confirmed (idempotent replay)", async () => {
    const a = await enqueue("u1", "batch.create", {}, "A"); apiMock.mockResolvedValue({ results: [{ op_id: a.op_id, status: "duplicate" }], applied: 0, duplicates: 1, rejected: 0 });
    await flushQueue("u1"); expect(await listQueue("u1")).toHaveLength(0);
  });
  it("keeps everything when the network is down", async () => {
    await enqueue("u1", "batch.create", {}, "A"); apiMock.mockRejectedValue(new ApiError(0, "NETWORK", "x", "network"));
    expect((await flushQueue("u1")).remaining).toBe(1); const q = await listQueue("u1"); expect(q[0].status).toBe("pending"); expect(q[0].attempts).toBe(1);
  });
  it("is scoped per user and discardable", async () => {
    const a = await enqueue("u1", "batch.create", {}, "A"); await enqueue("u2", "batch.create", {}, "B");
    expect(await listQueue("u1")).toHaveLength(1); await discard(a.op_id); expect(await listQueue("u1")).toHaveLength(0); expect(await listQueue("u2")).toHaveLength(1);
  });
  it("concurrent flushes send once", async () => {
    const a = await enqueue("u1", "batch.create", {}, "A"); apiMock.mockResolvedValue({ results: [{ op_id: a.op_id, status: "applied" }], applied: 1, duplicates: 0, rejected: 0 });
    await Promise.all([flushQueue("u1"), flushQueue("u1"), flushQueue("u1")]); expect(apiMock).toHaveBeenCalledTimes(1);
  });
});
describe("submitOrQueue", () => {
  const args = { userId: "u1", type: "batch.create" as const, data: { id: "x" }, label: "L" };
  it("online success reports the server result, queues nothing", async () => {
    const r = await submitOrQueue({ ...args, online: async () => "ok" }); expect(r).toEqual({ queued: false, result: "ok" }); expect(await listQueue("u1")).toHaveLength(0);
  });
  it("navigator offline -> queued, online() never called", async () => {
    Object.defineProperty(navigator, "onLine", { value: false, configurable: true }); const online = vi.fn();
    const r = await submitOrQueue({ ...args, online }); expect(r.queued).toBe(true); expect(online).not.toHaveBeenCalled(); expect(await listQueue("u1")).toHaveLength(1);
  });
  it("network failure -> queued; timeout -> NOT queued (outcome unknown); validation -> surfaced", async () => {
    expect((await submitOrQueue({ ...args, online: async () => { throw new ApiError(0, "NETWORK", "x", "network"); } })).queued).toBe(true);
    await expect(submitOrQueue({ ...args, online: async () => { throw new ApiError(0, "TIMEOUT", "x", "timeout"); } })).rejects.toMatchObject({ kind: "timeout" });
    await expect(submitOrQueue({ ...args, online: async () => { throw new ApiError(422, "V", "x", "validation"); } })).rejects.toMatchObject({ kind: "validation" });
    expect(await listQueue("u1")).toHaveLength(1);
  });
});
describe("snapshots", () => {
  it("are per-user, allow-listed and cleared on sign-out", async () => {
    setSnapshotOwner("u1"); await saveSnapshot(["batches", {}], [1]); await saveSnapshot(["ai-convs", {}], ["secret chat"]);
    expect((await loadSnapshot(["batches", {}]))?.data).toEqual([1]); expect(await loadSnapshot(["ai-convs", {}])).toBeUndefined();   // AI conversations are never stored
    setSnapshotOwner("u2"); expect(await loadSnapshot(["batches", {}])).toBeUndefined();
    setSnapshotOwner("u1"); await clearOfflineData(); expect(await loadSnapshot(["batches", {}])).toBeUndefined();
  });
});
