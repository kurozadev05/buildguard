import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ApiError, api } from "@/lib/api";
import { friendly } from "@/lib/errors";
import { safeNext } from "@/lib/auth-client";

const json = (status: number, body: unknown, headers: Record<string, string> = {}) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", ...headers } });
let fetchMock: ReturnType<typeof vi.fn>;
beforeEach(() => { fetchMock = vi.fn(); vi.stubGlobal("fetch", fetchMock); });
afterEach(() => { vi.unstubAllGlobals(); vi.useRealTimers(); });

describe("api()", () => {
  it("unwraps the success envelope and sends CSRF + request id + no tokens", async () => {
    fetchMock.mockResolvedValue(json(200, { success: true, data: { a: 1 }, meta: {} }));
    expect(await api("things")).toEqual({ a: 1 });
    const [url, init] = fetchMock.mock.calls[0]; expect(url).toBe("/bff/things");
    expect(init.headers["x-bg-csrf"]).toBe("1"); expect(init.headers["x-request-id"]).toMatch(/^[0-9a-f]{16}$/); expect(init.headers.authorization).toBeUndefined(); expect(init.credentials).toBe("same-origin");
  });
  it("normalises validation errors with field details and request id", async () => {
    fetchMock.mockResolvedValue(json(422, { success: false, error: { code: "VALIDATION_ERROR", message: "Invalid request", details: [{ field: "body.quantity_m3", message: "Input should be greater than 0", type: "x" }], request_id: "abc123" } }));
    const e = await api("batches", { method: "POST", body: {} }).catch((x) => x) as ApiError;
    expect(e).toBeInstanceOf(ApiError); expect(e.kind).toBe("validation"); expect(e.requestId).toBe("abc123");
    expect(friendly(e, (k) => k).fields).toEqual({ quantity_m3: "Input should be greater than 0" });
  });
  it("emits a session-expired event on 401", async () => {
    const seen = vi.fn(); window.addEventListener("bg:session-expired", seen);
    fetchMock.mockResolvedValue(json(401, { success: false, error: { code: "UNAUTHENTICATED", message: "x", details: [] } }));
    await expect(api("me", { retries: 0 })).rejects.toMatchObject({ kind: "auth" }); expect(seen).toHaveBeenCalledTimes(1);
    await expect(api("me", { retries: 0, silent401: true })).rejects.toBeTruthy(); expect(seen).toHaveBeenCalledTimes(1);
  });
  it("maps status codes to kinds", async () => {
    for (const [s, k] of [[403, "forbidden"], [404, "notfound"], [409, "conflict"], [429, "rate_limit"], [503, "server"]] as const) {
      fetchMock.mockResolvedValueOnce(json(s, { success: false, error: { code: "X", message: "m", details: [] } }));
      await expect(api("x", { method: "POST", body: {} })).rejects.toMatchObject({ kind: k });
    }
  });
  it("retries GET on network failure with backoff, but never retries a write", async () => {
    vi.useFakeTimers();
    fetchMock.mockRejectedValueOnce(new TypeError("fail")).mockResolvedValueOnce(json(200, { success: true, data: 7 }));
    const p = api<number>("x"); await vi.advanceTimersByTimeAsync(2000); expect(await p).toBe(7); expect(fetchMock).toHaveBeenCalledTimes(2);
    fetchMock.mockClear(); fetchMock.mockRejectedValue(new TypeError("fail"));
    await expect(api("x", { method: "POST", body: {} })).rejects.toMatchObject({ kind: "network" }); expect(fetchMock).toHaveBeenCalledTimes(1);
  });
  it("does not retry a 500 (could have side effects) but retries 503", async () => {
    vi.useFakeTimers(); fetchMock.mockResolvedValue(json(500, { success: false, error: { code: "INTERNAL", message: "x", details: [] } }));
    await expect(api("x")).rejects.toMatchObject({ kind: "server" }); expect(fetchMock).toHaveBeenCalledTimes(1);
  });
  it("reports timeouts and honours caller cancellation", async () => {
    vi.useFakeTimers(); fetchMock.mockImplementation((_u: string, init: RequestInit) => new Promise((_r, rej) => init.signal!.addEventListener("abort", () => rej(new DOMException("aborted", "AbortError")))));
    const p = api("slow", { timeoutMs: 50, retries: 0 }).catch((e) => e); await vi.advanceTimersByTimeAsync(60); expect((await p as ApiError).kind).toBe("timeout");
    const ac = new AbortController(); const q = api("slow", { signal: ac.signal, retries: 0 }).catch((e) => e); ac.abort(); expect(await q).toBeInstanceOf(DOMException);
  });
});
describe("friendly()", () => {
  it("never leaks raw server text for 5xx", () => {
    const e = new ApiError(500, "INTERNAL", "sqlalchemy.exc.OperationalError: no such table", "server", [], "rid1");
    const f = friendly(e, (k) => k); expect(f.message).toBe("err.server"); expect(JSON.stringify(f)).not.toContain("sqlalchemy");
  });
  it("marks auth/forbidden as not retryable", () => { expect(friendly(new ApiError(403, "F", "x", "forbidden"), (k) => k).retryable).toBe(false); expect(friendly(new ApiError(0, "N", "x", "network"), (k) => k).retryable).toBe(true); });
});
describe("safeNext()", () => {
  it.each([["/batches?x=1", "/batches?x=1"], ["//evil.com", "/"], ["https://evil.com", "/"], ["/\\evil.com", "/"], ["javascript:alert(1)", "/"], [null, "/"], ["", "/"]])("%s -> %s", (i, o) => expect(safeNext(i as string | null)).toBe(o));
});

import { cleanDetails } from "@/lib/api";
describe("cleanDetails()", () => {
  it("drops malformed / debug entries that dev-mode servers may send, keeps field errors", () => {
    expect(cleanDetails([{ debug: "ValueError: secret internals" }, { field: "body.qty", message: "too big", type: "x" }, null, "x", { field: 1, message: "m" }])).toEqual([{ field: "body.qty", message: "too big", type: "x" }]);
    expect(cleanDetails(undefined)).toEqual([]);
  });
});
