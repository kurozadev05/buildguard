import { describe, expect, it } from "vitest";
import { SseParser } from "@/lib/sse";

describe("SseParser", () => {
  it("parses whole events", () => {
    const evs = new SseParser().push('event: meta\ndata: {"conversation_id":"c1"}\n\nevent: delta\ndata: {"text":"Hi"}\n\n');
    expect(evs).toEqual([{ event: "meta", data: { conversation_id: "c1" } }, { event: "delta", data: { text: "Hi" } }]);
  });
  it("reassembles an event split across arbitrary chunks (incl. mid-line and mid-terminator)", () => {
    const p = new SseParser(); const whole = 'event: delta\ndata: {"text":"Hello wörld"}\n\n'; const out = [];
    for (const ch of whole) out.push(...p.push(ch));
    expect(out).toEqual([{ event: "delta", data: { text: "Hello wörld" } }]);
  });
  it("handles CRLF, comments and keep-alives", () => {
    expect(new SseParser().push(': ping\r\n\r\nevent: done\r\ndata: {"ok":true}\r\n\r\n')).toEqual([{ event: "done", data: { ok: true } }]);
  });
  it("skips malformed JSON instead of crashing", () => {
    const p = new SseParser(); expect(p.push("event: delta\ndata: {oops\n\n")).toEqual([]); expect(p.push('event: delta\ndata: {"text":"ok"}\n\n')).toHaveLength(1);
  });
});
