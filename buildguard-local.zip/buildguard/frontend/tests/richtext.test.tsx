import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { RichText } from "@/components/ui/RichText";

describe("RichText (AI output is untrusted)", () => {
  it("renders HTML/script as inert text", () => {
    const { container } = render(<RichText text={'<img src=x onerror="alert(1)"><script>alert(2)</script><b onclick=x>hi</b>'} />);
    expect(container.querySelector("img,script,b")).toBeNull(); expect(container.textContent).toContain("<script>alert(2)</script>");
  });
  it("never creates links or images, even from markdown or javascript: URLs", () => {
    const { container } = render(<RichText text={"[click](javascript:alert(1)) ![x](http://evil/x.png) https://evil.example <a href='javascript:1'>a</a>"} />);
    expect(container.querySelector("a,img,iframe,form")).toBeNull();
  });
  it("supports bold, code, lists, fences and source chips", () => {
    const { container } = render(<RichText text={"**Take** 2 samples [K1].\n\n- one\n- two\n\n```\nfck = 25\n```"} sources={[{ label: "K1", title: "Sampling", reference: "IS 456 Cl. 15", source: "kb" }]} />);
    expect(container.querySelector("strong")?.textContent).toBe("Take"); expect(container.querySelectorAll("li")).toHaveLength(2);
    expect(container.querySelector(".chip")?.getAttribute("title")).toContain("IS 456"); expect(container.querySelector("pre code")?.textContent).toContain("fck = 25");
  });
  it("handles an unterminated stream mid-token without crashing", () => {
    expect(() => render(<RichText text={"**bold unfinished and `code and [K"} />)).not.toThrow();
  });
});
