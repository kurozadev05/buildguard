import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { backendPath, csrfProblem } from "@/server/proxy";
import { refreshTokens, setCookieHeaders } from "@/server/session";

beforeEach(() => { process.env.BACKEND_URL = "http://backend.test"; });
afterEach(() => vi.unstubAllGlobals());
const req = (method: string, headers: Record<string, string> = {}) => new NextRequest("http://app.test/bff/x", { method, headers: { host: "app.test", ...headers } });

describe("proxy path safety", () => {
  it("maps to /api and encodes segments", () => { expect(backendPath(["batches", "abc"], "?a=1")).toBe("/api/batches/abc?a=1"); });
  it.each([[[".."]], [["batches", ".."]], [["a%2fb"]], [["a/b"]], [[""]], [[]]])("rejects %j", (segs) => { expect(backendPath(segs as string[], "")).toBeNull(); });
  it.each(["login", "register", "refresh", "token", "logout"])("blocks token-issuing endpoint auth/%s", (p) => { expect(backendPath(["auth", p], "")).toBeNull(); });
  it("allows other auth endpoints", () => { expect(backendPath(["auth", "me"], "")).toBe("/api/auth/me"); expect(backendPath(["auth", "change-password"], "")).toBe("/api/auth/change-password"); });
});
describe("CSRF", () => {
  it("GET needs nothing", () => expect(csrfProblem(req("GET"))).toBeNull());
  it("POST needs the custom header", () => expect(csrfProblem(req("POST"))).toMatch(/CSRF/));
  it("POST from a foreign origin is refused", () => expect(csrfProblem(req("POST", { "x-bg-csrf": "1", origin: "https://evil.example" }))).toMatch(/Cross-origin/));
  it("POST from the same origin passes", () => expect(csrfProblem(req("POST", { "x-bg-csrf": "1", origin: "http://app.test" }))).toBeNull());
  it("honours x-forwarded-host behind a reverse proxy", () => expect(csrfProblem(req("DELETE", { "x-bg-csrf": "1", origin: "https://app.example.com", "x-forwarded-host": "app.example.com" }))).toBeNull());
});
describe("cookies", () => {
  it("are HttpOnly + SameSite=Strict; cleared with Max-Age=0", () => {
    const c = setCookieHeaders({ access: "a", refresh: "r", expiresAt: Date.now() + 900_000 }); expect(c).toHaveLength(2); for (const x of c) { expect(x).toContain("HttpOnly"); expect(x).toContain("SameSite=Strict"); expect(x).toContain("Path=/"); }
    for (const x of setCookieHeaders(null)) expect(x).toContain("Max-Age=0");
  });
  it("adds Secure in production config", () => { process.env.COOKIE_SECURE = "true"; expect(setCookieHeaders({ access: "a", refresh: "r", expiresAt: Date.now() + 1000 })[0]).toContain("Secure"); delete process.env.COOKIE_SECURE; });
});
describe("refresh single-flight", () => {
  it("N concurrent refreshes of one token call the backend once; later calls reuse the result", async () => {
    const f = vi.fn().mockImplementation(async () => { await new Promise((r) => setTimeout(r, 20)); return new Response(JSON.stringify({ success: true, data: { access_token: "A2", refresh_token: "R2", expires_at: new Date(Date.now() + 9e5).toISOString() } }), { status: 200 }); });
    vi.stubGlobal("fetch", f);
    const out = await Promise.all(Array.from({ length: 10 }, () => refreshTokens("R1-unique"))); expect(f).toHaveBeenCalledTimes(1); expect(out.every((t) => t?.refresh === "R2")).toBe(true);
    await refreshTokens("R1-unique"); expect(f).toHaveBeenCalledTimes(1);
  });
  it("returns null for a revoked token, throws when the backend is down", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("{}", { status: 401 }))); expect(await refreshTokens("dead-token")).toBeNull();
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("down"))); await expect(refreshTokens("other-token")).rejects.toThrow();
  });
});
