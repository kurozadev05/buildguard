"use client";
import { ShieldCheck } from "lucide-react";
import { Suspense, useState } from "react";
import { RequireCap } from "@/components/AppShell";
import { useProject } from "@/components/Providers";
import { DataTable } from "@/components/ui/DataTable";
import { Field, Input } from "@/components/ui/form";
import { Alert, Button, EmptyState, ErrorState, FormError, PageHeader, SkeletonRows } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { fmtDateTime } from "@/lib/format";
import { useApiMutation, useDebounced, useInfiniteApi } from "@/lib/hooks";
import { useT } from "@/lib/i18n";

interface Entry { id: number; ts: string; actor: string; action: string; entity: string; entity_id: string | null; details: Record<string, unknown>; entry_hash: string }
function Inner() {
  const { lang } = useT(); const { current } = useProject(); const [action, setAction] = useState(""); const a = useDebounced(action, 400);
  const q = useInfiniteApi<Entry>(["audit"], "audit", { project_id: current?.id, action: a || undefined }, 30, { enabled: !!current });
  const [res, setRes] = useState<{ ok: boolean; checked: number; message: string } | null>(null);
  const verify = useApiMutation(() => api<{ ok: boolean; checked: number; message: string }>("audit/verify"), { onSuccess: setRes });
  return (
    <RequireCap cap="audit">
      <PageHeader title="Audit log" subtitle="Every change is recorded in a hash-chained log that shows tampering." actions={<Button loading={verify.isPending} onClick={() => verify.mutate(undefined)}><ShieldCheck size={16} aria-hidden />Verify chain</Button>} />
      {res && <Alert tone={res.ok ? "success" : "danger"} title={res.ok ? "✓ Chain intact" : "✕ Chain broken"}>{res.message} ({res.checked} entries checked)</Alert>}<FormError error={verify.error} />
      <div className="card"><Field plain label="Filter by action" hint="e.g. test.create, batch.create, risk.assess"><Input value={action} onChange={(e) => setAction(e.target.value)} /></Field></div>
      {q.isLoading ? <SkeletonRows /> : q.error ? <ErrorState error={q.error} onRetry={() => q.refetch()} /> : q.items.length === 0 ? <EmptyState title="No entries" hint="Nothing matches this filter." /> : (<>
        <DataTable<Entry> caption="Audit log" rowKey={(r) => String(r.id)} rows={q.items} columns={[{ key: "t", header: "When", cell: (r) => fmtDateTime(r.ts, lang) }, { key: "a", header: "Who", cell: (r) => r.actor }, { key: "x", header: "Action", cell: (r) => <span className="mono">{r.action}</span> }, { key: "e", header: "Record", cell: (r) => `${r.entity}${r.entity_id ? ` ${r.entity_id.slice(0, 8)}…` : ""}` }, { key: "h", header: "Hash", cell: (r) => <span className="mono">{r.entry_hash.slice(0, 10)}…</span> }]} />
        {q.hasNextPage && <div className="row" style={{ justifyContent: "center" }}><Button onClick={() => q.fetchNextPage()} loading={q.isFetchingNextPage}>Load more</Button></div>}</>)}
    </RequireCap>
  );
}
export default function Page() { return <Suspense fallback={<SkeletonRows />}><Inner /></Suspense>; }
