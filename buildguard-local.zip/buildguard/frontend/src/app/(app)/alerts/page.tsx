"use client";
import { AlertTriangle, XCircle } from "lucide-react";
import { Suspense } from "react";
import Link from "next/link";
import { useProject, useSession } from "@/components/Providers";
import { useToast } from "@/components/ui/overlay";
import { Badge, Button, EmptyState, ErrorState, PageHeader, SkeletonRows } from "@/components/ui/ui";
import { Field, Select } from "@/components/ui/form";
import { api } from "@/lib/api";
import { timeAgo } from "@/lib/format";
import { useApiMutation, useInfiniteApi } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { can } from "@/lib/perm";
import type { Alert } from "@/lib/types";
import { useUrlParams } from "@/lib/urlstate";

function Inner() {
  const { t } = useT(); const { current } = useProject(); const { user } = useSession(); const toast = useToast(); const [f, setF] = useUrlParams(["all"] as const);
  const q = useInfiniteApi<Alert>(["alerts"], "alerts", { project_id: current?.id, unacknowledged: f.all ? undefined : true }, 20, { offline: true, enabled: !!current });
  const ack = useApiMutation((id: string) => api(`alerts/${id}/ack`, { method: "POST" }), { invalidate: [["alerts"], ["dashboard"]], onSuccess: () => toast({ kind: "success", title: "Alert acknowledged" }) });
  return (
    <div className="stack">
      <PageHeader title={t("nav.alerts")} />
      <div className="card"><Field plain label="Show"><Select value={f.all} onChange={(e) => setF({ all: e.target.value })}><option value="">Needs acknowledgement</option><option value="1">All alerts</option></Select></Field></div>
      {q.isLoading ? <SkeletonRows /> : q.error ? <ErrorState error={q.error} onRetry={() => q.refetch()} /> : q.items.length === 0 ? <EmptyState title="No alerts" hint="✓ Nothing needs your attention right now." /> : (
        <div className="card"><ul className="list">{q.items.map((a) => (
          <li key={a.id} className="row between"><div className="grow"><Badge tone={a.severity === "high" ? "danger" : "warning"} icon={a.severity === "high" ? <XCircle size={14} aria-hidden /> : <AlertTriangle size={14} aria-hidden />}>{a.severity}</Badge> {a.message}
            <div className="hint">{timeAgo(a.created_at)}{a.batch_id && <> · <Link href={`/batches/${a.batch_id}`}>Batch</Link></>}{a.test_id && <> · <Link href={`/tests/${a.test_id}`}>Test</Link></>}{a.element_id && <> · <Link href="/risk">Risk map</Link></>}</div></div>
            {a.acknowledged_at ? <Badge tone="success">✓ Acknowledged</Badge> : can(user, "write") && <Button size="sm" loading={ack.isPending && ack.variables === a.id} onClick={() => ack.mutate(a.id)}>Acknowledge</Button>}</li>))}</ul>
          {q.hasNextPage && <div className="row" style={{ justifyContent: "center" }}><Button onClick={() => q.fetchNextPage()} loading={q.isFetchingNextPage}>{t("common.loadMore")}</Button></div>}</div>
      )}
    </div>
  );
}
export default function Page() { return <Suspense fallback={<SkeletonRows />}><Inner /></Suspense>; }
