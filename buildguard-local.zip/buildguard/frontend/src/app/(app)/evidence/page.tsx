"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { DocList } from "@/components/DocList";
import { useProject, useSession } from "@/components/Providers";
import { buildValues, TEST_TYPES, TestFields, type TState } from "@/components/TestFields";
import { UploadBox } from "@/components/UploadBox";
import { Field, Select } from "@/components/ui/form";
import { Modal, useToast } from "@/components/ui/overlay";
import { Alert, Badge, Button, Card, EmptyState, ErrorState, FormError, PageHeader, Progress, SkeletonRows, TabPanel, Tabs } from "@/components/ui/ui";
import { RequireCap } from "@/components/AppShell";
import { api, upload } from "@/lib/api";
import { checkFile } from "@/components/UploadBox";
import { useApiMutation, useApiQuery } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import type { Batch } from "@/lib/types";

interface Draft { id: string; status: string; document_id: string; provider: string; extracted: Record<string, unknown> }
interface Reading { document_id: string; reading: null | { raw_value: number | null; unit: string | null; strength_mpa: number | null; plausible: boolean; legible: boolean }; needs_confirmation: boolean; note: string }
function FilePick({ onFile, label, disabled }: { onFile: (f: File) => void; label: string; disabled?: boolean }) {
  const [problem, setProblem] = useState<string | null>(null);
  return (<div className="stack-sm"><label className="btn"><span>{label}</span><input type="file" className="sr-only" accept="image/jpeg,image/png,image/webp,application/pdf" capture="environment" disabled={disabled} onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; const p = checkFile(f); setProblem(p); if (!p) onFile(f); e.target.value = ""; }} /></label>{problem && <p className="err-text" role="alert">✕ {problem}</p>}</div>);
}
export default function EvidencePage() {
  const { t } = useT(); const { current } = useProject(); const { user } = useSession(); const toast = useToast(); const router = useRouter(); const [tab, setTab] = useState("files");
  const [batchId, setBatchId] = useState(""); const [size, setSize] = useState("150"); const [pct, setPct] = useState<number | null>(null);
  const batches = useApiQuery<Batch[]>(["batches", "picker"], "batches", { query: { project_id: current?.id, limit: 100 }, enabled: !!current, offline: true });
  const drafts = useApiQuery<Draft[]>(["ocr-drafts"], "ocr/drafts", { query: { status: "pending", limit: 20 }, enabled: tab === "ocr" });
  const [reading, setReading] = useState<Reading | null>(null); const [err, setErr] = useState<unknown>(null);
  const [dlg, setDlg] = useState<Draft | null>(null); const [s, setS] = useState<TState>({ age_days: "28" }); const [type, setType] = useState("cube_compressive_strength"); const [dBatch, setDBatch] = useState("");
  const built = buildValues(type, s);
  async function send(path: "ocr/extract" | "ai/read-display", f: File) {
    if (!current) return; setErr(null); setPct(0); const fd = new FormData(); fd.append("file", f); fd.append("project_id", current.id); if (batchId) fd.append("batch_id", batchId); if (path === "ai/read-display") fd.append("cube_size_mm", size);
    try { const r = await upload<Reading & { draft_id?: string }>(path, fd, { onProgress: setPct }); if (path === "ai/read-display") setReading(r); else { toast({ kind: "success", title: "Report saved as a draft", message: "Nothing is official until you confirm it." }); void drafts.refetch(); } }
    catch (e) { setErr(e); } setPct(null);
  }
  const confirm = useApiMutation(() => api(`ocr/drafts/${dlg!.id}/confirm`, { method: "POST", body: { batch_id: dBatch || undefined, test_type: type, age_days: built.age_days, values: built.values } }), { invalidate: [["ocr-drafts"], ["tests"], ["dashboard"]], onSuccess: () => { setDlg(null); toast({ kind: "success", title: "Confirmed and validated" }); } });
  const reject = useApiMutation((id: string) => api(`ocr/drafts/${id}/reject`, { method: "POST" }), { invalidate: [["ocr-drafts"]], onSuccess: () => toast({ kind: "info", title: "Draft rejected" }) });
  const picker = <Field label="Batch (optional)"><Select value={batchId} onChange={(e) => setBatchId(e.target.value)}><option value="">Not linked</option>{batches.data?.map((b) => <option key={b.id} value={b.id}>{b.batch_code}</option>)}</Select></Field>;
  if (!current) return <EmptyState title="Choose a project first" />;
  return (
    <RequireCap cap="any">
      <PageHeader title="Evidence" subtitle="Photos, lab reports and machine readings, each sealed with a hash." />
      <Tabs label="Evidence sections" value={tab} onChange={setTab} tabs={[{ id: "files", label: "Files" }, { id: "ocr", label: "Lab report → draft" }, { id: "display", label: "Machine display" }]} />
      <TabPanel id="files" value={tab}><div className="stack"><Card title="All files"><DocList query={{}} /></Card>{user && user.role !== "client" && user.role !== "auditor" && <Card title="Upload"><UploadBox projectId={current.id} kinds={["photo", "report", "delivery_challan", "lab_certificate"]} /></Card>}</div></TabPanel>
      <TabPanel id="ocr" value={tab}>
        <div className="stack">
          <Card title="Read a lab report"><div className="stack-sm"><Alert tone="info">The report is read into a <strong>draft</strong>. You check and confirm every value before it becomes a test result.</Alert>{picker}<FilePick label="Take photo or choose report" onFile={(f) => send("ocr/extract", f)} disabled={pct !== null} />{pct !== null && <Progress value={pct} max={100} label="Upload progress" />}<FormError error={err} /></div></Card>
          <Card title="Drafts waiting for you">{drafts.isLoading ? <SkeletonRows rows={2} /> : drafts.error ? <ErrorState error={drafts.error} compact onRetry={() => drafts.refetch()} /> : !drafts.data?.length ? <p className="muted">No drafts waiting.</p> : <ul className="list">{drafts.data.map((d) => <li key={d.id} className="row between"><div><Badge tone="warning">⚠ Needs confirmation</Badge> <span className="hint">{d.provider === "none" ? "Not machine-read: enter values manually" : `Read by ${d.provider}`}</span></div><div className="row"><a className="btn sm" href={`/bff/documents/${d.document_id}/download`} target="_blank" rel="noopener noreferrer">View report</a><Button size="sm" variant="primary" onClick={() => { setDlg(d); setS({ age_days: "28" }); }}>Review</Button><Button size="sm" onClick={() => reject.mutate(d.id)}>Reject</Button></div></li>)}</ul>}</Card>
        </div>
      </TabPanel>
      <TabPanel id="display" value={tab}>
        <Card title="Read a testing-machine display"><div className="stack-sm"><Alert tone="info">Photograph the machine display. The value is a <strong>draft</strong> to check against the photo, never saved automatically.</Alert>{picker}<Field label="Cube size"><Select value={size} onChange={(e) => setSize(e.target.value)}><option value="150">150 mm</option><option value="100">100 mm</option></Select></Field><FilePick label="Take photo of display" onFile={(f) => send("ai/read-display", f)} disabled={pct !== null} />{pct !== null && <Progress value={pct} max={100} label="Upload progress" />}<FormError error={err} />
          {reading && <Alert tone={reading.reading?.plausible ? "success" : "warning"} title={reading.reading?.plausible ? `Reads about ${reading.reading.strength_mpa} N/mm²` : "Could not read reliably"}>{reading.note}{reading.reading?.plausible && <div style={{ marginTop: 6 }}><Button size="sm" variant="primary" onClick={() => router.push(`/tests/new?${batchId ? `batch=${batchId}&` : ""}spec1=${reading.reading!.strength_mpa}&doc=${reading.document_id}`)}>Use in a new test</Button></div>}</Alert>}</div></Card>
      </TabPanel>
      <Modal open={!!dlg} onClose={() => setDlg(null)} title="Confirm report values" footer={<><Button onClick={() => setDlg(null)}>{t("common.cancel")}</Button><Button variant="primary" loading={confirm.isPending} disabled={!!Object.keys(built.errors).length} onClick={() => confirm.mutate(undefined)}>Confirm</Button></>}>
        <div className="stack"><p className="small muted">Compare with the report, then enter the values as they appear.</p>
          <details><summary>What was read automatically</summary><pre className="mono" style={{ overflowX: "auto" }} tabIndex={0}>{JSON.stringify(dlg?.extracted, null, 2)}</pre></details>
          <div className="form-grid"><Field label="Batch" required><Select value={dBatch} onChange={(e) => setDBatch(e.target.value)}><option value="">Choose…</option>{batches.data?.map((b) => <option key={b.id} value={b.id}>{b.batch_code}</option>)}</Select></Field>
            <Field label="Test type"><Select value={type} onChange={(e) => { setType(e.target.value); setS({ age_days: "28" }); }}>{TEST_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</Select></Field><TestFields type={type} s={s} set={(k, v) => setS((x) => ({ ...x, [k]: v }))} errors={built.errors} /></div><FormError error={confirm.error} /></div>
      </Modal>
    </RequireCap>
  );
}
