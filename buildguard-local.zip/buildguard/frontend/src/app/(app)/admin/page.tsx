"use client";
import { useState } from "react";
import { RequireCap } from "@/components/AppShell";
import { DataTable } from "@/components/ui/DataTable";
import { Select } from "@/components/ui/form";
import { Modal, useConfirm, useToast } from "@/components/ui/overlay";
import { Alert, Badge, Button, Card, ErrorState, FormError, PageHeader, SkeletonRows, TabPanel, Tabs } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { fmtNum } from "@/lib/format";
import { useApiMutation, useApiQuery, useInfiniteApi } from "@/lib/hooks";
import type { AiStatus, Role, User } from "@/lib/types";

const ROLES: Role[] = ["admin", "site_engineer", "qa", "lab", "client", "auditor"];
export default function AdminPage() {
  const [tab, setTab] = useState("users"); const toast = useToast(); const confirm = useConfirm(); const [temp, setTemp] = useState<{ email: string; pw: string } | null>(null);
  const users = useInfiniteApi<User>(["users"], "auth/users", {}, 50);
  const patch = useApiMutation((v: { id: string; body: Partial<User> }) => api(`auth/users/${v.id}`, { method: "PATCH", body: v.body }), { invalidate: [["users"]], onSuccess: () => toast({ kind: "success", title: "User updated" }) });
  const reset = useApiMutation((u: User) => api<{ temporary_password: string }>(`auth/users/${u.id}/reset-password`, { method: "POST" }).then((r) => ({ u, r })), { onSuccess: ({ u, r }) => setTemp({ email: u.email, pw: r.temporary_password }) });
  const status = useApiQuery<AiStatus>(["ai-status"], "ai/status", { enabled: tab === "ai" });
  const usage = useApiQuery<Record<string, unknown>>(["ai-usage"], "ai/usage/summary", { query: { days: 7 }, enabled: tab === "ai" });
  const metrics = useApiQuery<Record<string, unknown>>(["ai-metrics"], "ai/metrics", { enabled: tab === "ai" });
  return (
    <RequireCap cap="admin">
      <PageHeader title="Administration" />
      <Tabs label="Admin sections" value={tab} onChange={setTab} tabs={[{ id: "users", label: "Users" }, { id: "ai", label: "AI usage & health" }]} />
      <TabPanel id="users" value={tab}>
        {users.isLoading ? <SkeletonRows /> : users.error ? <ErrorState error={users.error} onRetry={() => users.refetch()} /> : (<>
          <DataTable<User> caption="Users" rowKey={(u) => u.id} rows={users.items} columns={[
            { key: "n", header: "Name", cell: (u) => <strong>{u.full_name}</strong> }, { key: "e", header: "Email", cell: (u) => u.email },
            { key: "r", header: "Role", cell: (u) => <Select aria-label={`Role for ${u.full_name}`} value={u.role} style={{ minHeight: 36 }} onChange={async (e) => { if (await confirm({ title: "Change role?", message: `${u.full_name} will become ${e.target.value.replace("_", " ")}.`, confirmLabel: "Change" })) patch.mutate({ id: u.id, body: { role: e.target.value as Role } }); }}>{ROLES.map((r) => <option key={r} value={r}>{r.replace("_", " ")}</option>)}</Select> },
            { key: "a", header: "Status", cell: (u) => <Badge tone={u.is_active ? "success" : "neutral"}>{u.is_active ? "✓ Active" : "Disabled"}</Badge> },
            { key: "x", header: "Actions", cell: (u) => <div className="row"><Button size="sm" onClick={async () => { if (await confirm({ title: u.is_active ? "Disable account?" : "Enable account?", message: u.is_active ? `${u.full_name} will be signed out and unable to sign in.` : `${u.full_name} will be able to sign in again.`, confirmLabel: u.is_active ? "Disable" : "Enable", danger: u.is_active })) patch.mutate({ id: u.id, body: { is_active: !u.is_active } }); }}>{u.is_active ? "Disable" : "Enable"}</Button>
              <Button size="sm" onClick={async () => { if (await confirm({ title: "Reset password?", message: `A temporary password will be created for ${u.email}. Their current sessions end.`, confirmLabel: "Reset", danger: true })) reset.mutate(u); }}>Reset password</Button></div> }]} />
          <FormError error={patch.error ?? reset.error} />
          {users.hasNextPage && <div className="row" style={{ justifyContent: "center" }}><Button onClick={() => users.fetchNextPage()} loading={users.isFetchingNextPage}>Load more</Button></div>}</>)}
      </TabPanel>
      <TabPanel id="ai" value={tab}>
        <div className="stack">
          <Card title="Assistant status">{status.isLoading ? <SkeletonRows rows={2} /> : status.error ? <ErrorState error={status.error} compact onRetry={() => status.refetch()} /> : status.data && <div className="row"><Badge tone={status.data.enabled ? "success" : "warning"}>{status.data.enabled ? "✓ Model connected" : "⚠ Retrieval only"}</Badge><span className="small">Mode: {status.data.mode}{status.data.admin?.provider ? ` · ${status.data.admin.provider}/${status.data.admin.model}` : ""} · Rate limit {status.data.limits.requests_per_minute}/min · Daily budget {fmtNum(status.data.limits.daily_token_budget, 0)} tokens</span></div>}</Card>
          <Card title="Usage, last 7 days">{usage.isLoading ? <SkeletonRows rows={2} /> : usage.error ? <ErrorState error={usage.error} compact onRetry={() => usage.refetch()} /> : <pre className="mono" style={{ overflowX: "auto", margin: 0 }} tabIndex={0}>{JSON.stringify(usage.data, null, 2)}</pre>}</Card>
          <Card title="Runtime metrics">{metrics.isLoading ? <SkeletonRows rows={2} /> : metrics.error ? <ErrorState error={metrics.error} compact onRetry={() => metrics.refetch()} /> : <pre className="mono" style={{ overflowX: "auto", margin: 0 }} tabIndex={0}>{JSON.stringify(metrics.data, null, 2)}</pre>}</Card>
        </div>
      </TabPanel>
      <Modal open={!!temp} onClose={() => setTemp(null)} title="Temporary password" footer={<Button variant="primary" onClick={() => setTemp(null)}>Done</Button>}>
        <div className="stack"><Alert tone="warning">Shown once. Share it privately with {temp?.email}; they must change it after signing in.</Alert><div className="mono card" style={{ userSelect: "all", fontSize: "1.1rem" }}>{temp?.pw}</div><Button onClick={() => { void navigator.clipboard?.writeText(temp?.pw ?? ""); toast({ kind: "success", title: "Copied" }); }}>Copy</Button></div>
      </Modal>
    </RequireCap>
  );
}
