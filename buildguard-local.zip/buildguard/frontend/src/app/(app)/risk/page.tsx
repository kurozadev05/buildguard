"use client";
import { Activity } from "lucide-react";
import { useState } from "react";
import { useProject, useSession } from "@/components/Providers";
import { Field, Input, Select, Textarea } from "@/components/ui/form";
import { Modal, useToast } from "@/components/ui/overlay";
import { Alert, Badge, Button, EmptyState, ErrorState, FormError, PageHeader, SkeletonRows, StaleNote, TabPanel, Tabs } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { fmtDate, fmtNum, OBS_LABEL, uuid } from "@/lib/format";
import { useApiMutation, useApiQuery } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { submitOrQueue } from "@/lib/offline/queue";
import { can } from "@/lib/perm";
import type { RiskRow } from "@/lib/types";

const tone = (l: string) => (l === "High" || l === "Very High" ? "danger" : l === "Moderate" ? "warning" : "success") as "danger" | "warning" | "success";
const mark = (l: string) => (tone(l) === "danger" ? "✕" : tone(l) === "warning" ? "⚠" : "✓");
const TREND: Record<string, string> = { DETERIORATING: "↘ Deteriorating", STABLE: "→ Stable", IMPROVING: "↗ Improving", INSUFFICIENT_DATA: "Not enough data" };

function ElementPanel({ row, onClose }: { row: RiskRow; onClose: () => void }) {
  const { lang } = useT(); const { user } = useSession(); const toast = useToast(); const [tab, setTab] = useState("why");
  const hist = useApiQuery<{ history: { computed_at: string; score: number; level: string; trend: string }[] }>(["risk-hist", row.element_id], `durability/elements/${row.element_id}/history`, { enabled: tab === "history" });
  const obs = useApiQuery<{ id: string; kind: string; value: number; unit: string | null; observed_at: string; notes: string | null }[]>(["obs", row.element_id], `elements/${row.element_id}/observations`, { query: { limit: 30 }, enabled: tab === "obs" });
  const bat = useApiQuery<{ batches: { id: string; batch_code: string; grade: string; status: string }[] }>(["el-batches", row.element_id], `elements/${row.element_id}/batches`, { enabled: tab === "batches" });
  const [o, setO] = useState({ kind: "crack_width_mm", value: "", notes: "" });
  const assess = useApiMutation(() => api(`durability/elements/${row.element_id}/assess`, { method: "POST", query: { persist: true, lang } }), { invalidate: [["risk"], ["risk-hist"], ["dashboard"], ["alerts"]], onSuccess: () => toast({ kind: "success", title: "Risk re-assessed" }) });
  const add = useApiMutation(async () => { const body = { id: uuid(), element_id: row.element_id, kind: o.kind, value: Number(o.value), ...(o.notes ? { notes: o.notes } : {}) }; return submitOrQueue({ userId: user!.id, type: "observation.create", data: body, label: `${OBS_LABEL[o.kind]}: ${o.value}`, online: () => api("observations", { method: "POST", body }) }); },
    { invalidate: [["obs"]], onSuccess: (r) => { setO({ ...o, value: "", notes: "" }); toast(r.queued ? { kind: "info", title: "Saved on this device", message: "Not yet confirmed by the server." } : { kind: "success", title: "Observation recorded", message: "Re-assess to update the score." }); } });
  return (
    <Modal open onClose={onClose} title={row.path.split(" → ").slice(1).join(" › ") || row.path} footer={<>{can(user, "write") && <Button loading={assess.isPending} onClick={() => assess.mutate(undefined)}>Re-assess now</Button>}<Button variant="primary" onClick={onClose}>Close</Button></>}>
      <div className="stack">
        <div className="row"><Badge tone={tone(row.level)}>{mark(row.level)} {row.level} · {fmtNum(row.score, 0)}/100</Badge><span className="small muted">{TREND[row.trend] ?? row.trend}</span></div>
        <Tabs label="Element sections" value={tab} onChange={setTab} tabs={[{ id: "why", label: "Why" }, { id: "obs", label: "Observations" }, { id: "history", label: "History" }, { id: "batches", label: "Concrete used" }]} />
        <TabPanel id="why" value={tab}><ul className="list">{row.top_factors.map((f) => <li key={f.factor}><strong>{f.factor}</strong> <span className="badge neutral">+{f.points}</span><div className="small">{f.detail}</div><div className="hint">{f.reference}</div></li>)}</ul>
          {row.recommendations.length > 0 && <Alert tone="info" title="Suggested next steps">{row.recommendations.join(" ")}</Alert>}</TabPanel>
        <TabPanel id="obs" value={tab}>
          {can(user, "write") && <form className="stack-sm" onSubmit={(e) => { e.preventDefault(); if (o.value !== "" && Number.isFinite(Number(o.value))) add.mutate(undefined); }}><div className="form-grid two"><Field label="Measurement" required><Select value={o.kind} onChange={(e) => setO({ ...o, kind: e.target.value })}>{Object.entries(OBS_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field><Field label="Value" required><Input type="number" inputMode="decimal" step="any" value={o.value} onChange={(e) => setO({ ...o, value: e.target.value })} /></Field></div><Field label="Notes"><Textarea value={o.notes} onChange={(e) => setO({ ...o, notes: e.target.value })} /></Field><FormError error={add.error} /><div className="actions"><Button type="submit" variant="primary" loading={add.isPending} disabled={o.value === ""}>Record</Button></div></form>}
          {obs.isLoading ? <SkeletonRows rows={2} /> : obs.error ? <ErrorState error={obs.error} compact onRetry={() => obs.refetch()} /> : !obs.data?.length ? <p className="muted">No observations yet.</p> : <ul className="list">{obs.data.map((x) => <li key={x.id}><strong>{OBS_LABEL[x.kind] ?? x.kind}: {x.value}</strong> <span className="hint">{fmtDate(x.observed_at, lang)}</span>{x.notes && <div className="small">{x.notes}</div>}</li>)}</ul>}
        </TabPanel>
        <TabPanel id="history" value={tab}>{hist.isLoading ? <SkeletonRows rows={2} /> : hist.error ? <ErrorState error={hist.error} compact onRetry={() => hist.refetch()} /> : !hist.data?.history.length ? <p className="muted">No earlier assessments.</p> : <ul className="list">{hist.data.history.map((h) => <li key={h.computed_at}>{fmtDate(h.computed_at, lang)}: <Badge tone={tone(h.level)}>{mark(h.level)} {h.level} · {fmtNum(h.score, 0)}</Badge></li>)}</ul>}</TabPanel>
        <TabPanel id="batches" value={tab}>{bat.isLoading ? <SkeletonRows rows={2} /> : bat.error ? <ErrorState error={bat.error} compact onRetry={() => bat.refetch()} /> : !bat.data?.batches.length ? <p className="muted">No batch has been linked to this element.</p> : <ul className="list">{bat.data.batches.map((b) => <li key={b.id}><a href={`/batches/${b.id}`}>{b.batch_code}</a> · {b.grade}</li>)}</ul>}</TabPanel>
      </div>
    </Modal>
  );
}
export default function RiskPage() {
  const { current } = useProject(); const [sel, setSel] = useState<RiskRow | null>(null);
  const q = useApiQuery<RiskRow[]>(["risk"], current ? `durability/projects/${current.id}/risk-map` : null, { enabled: !!current, offline: true });
  return (
    <div className="stack">
      <PageHeader title="Durability risk map" subtitle="A risk indicator to prioritise inspections. Not a structural assessment." />
      <StaleNote at={q.savedAt} />
      {q.isLoading ? <SkeletonRows /> : q.error ? <ErrorState error={q.error} onRetry={() => q.refetch()} /> : !q.data?.length ? <EmptyState icon={<Activity size={36} aria-hidden />} title="No elements assessed yet" hint="Add structural elements on the project page and record observations (cracks, moisture, UPV)." /> : (
        <div className="grid cols-2">{[...q.data].sort((a, b) => b.score - a.score).map((r) => (
          <button key={r.element_id} className="card" style={{ textAlign: "left", cursor: "pointer", font: "inherit" }} onClick={() => setSel(r)} aria-label={`${r.path}, ${r.level} risk`}>
            <div className="row between"><strong style={{ overflowWrap: "anywhere" }}>{r.path.split(" → ").slice(1).join(" › ") || r.path}</strong><Badge tone={tone(r.level)}>{mark(r.level)} {r.level}</Badge></div>
            <div className="small muted">Score {fmtNum(r.score, 0)}/100 · {TREND[r.trend] ?? r.trend}</div>{r.top_factors[0] && <div className="small">Main factor: {r.top_factors[0].factor}</div>}</button>))}</div>
      )}
      {sel && <ElementPanel row={sel} onClose={() => setSel(null)} />}
    </div>
  );
}
