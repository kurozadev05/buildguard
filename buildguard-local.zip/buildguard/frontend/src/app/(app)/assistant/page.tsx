"use client";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowDown, Copy, MessageSquare, Plus, RefreshCw, Send, Square, Trash2 } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { useProject } from "@/components/Providers";
import { Field, Input, Textarea } from "@/components/ui/form";
import { useConfirm, useToast } from "@/components/ui/overlay";
import { RichText } from "@/components/ui/RichText";
import { Alert, Button, Card, EmptyState, ErrorState, FormError, PageHeader, SkeletonRows, TabPanel, Tabs } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { friendly } from "@/lib/errors";
import { useApiMutation, useApiQuery, useDebounced } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { streamChat } from "@/lib/sse";
import type { AiSource, AiStatus, ChatDone, ConvMessage, Conversation } from "@/lib/types";

interface Msg { id: string; role: "user" | "assistant"; content: string; state: "streaming" | "done" | "stopped" | "error"; sources?: AiSource[]; tools?: string[]; notice?: string; error?: string }
const STARTERS = ["How many cube samples do I need for 30 m³ of M25 concrete?", "What is the acceptable slump for a heavily reinforced column?", "When should a batch be flagged and what happens next?", "Explain how curing affects durability."];
const TOOL_LABEL: Record<string, string> = { get_batch: "Looked up a batch", get_test: "Read a test result", list_alerts: "Checked alerts", search_knowledge: "Searched IS notes" };
let seq = 0; const mid = () => `m${++seq}`;

function Chat() {
  const { t, lang } = useT(); const { current } = useProject(); const toast = useToast(); const confirm = useConfirm(); const qc = useQueryClient();
  const status = useApiQuery<AiStatus>(["ai-status"], "ai/status", { staleTime: 5 * 60_000 });
  const convs = useApiQuery<Conversation[]>(["ai-convs"], "ai/conversations", { query: { limit: 30 } });
  const [msgs, setMsgs] = useState<Msg[]>([]); const [conv, setConv] = useState<string | null>(null); const [text, setText] = useState(""); const [busy, setBusy] = useState(false); const [preErr, setPreErr] = useState<unknown>(null);
  const ac = useRef<AbortController | null>(null); const box = useRef<HTMLDivElement>(null); const stick = useRef(true); const [showJump, setShowJump] = useState(false); const [announce, setAnnounce] = useState("");
  const ta = useRef<HTMLTextAreaElement>(null); const max = status.data?.limits.max_message_chars ?? 2000;

  useEffect(() => { const el = box.current; if (el && stick.current) el.scrollTop = el.scrollHeight; }, [msgs]);
  const onScroll = () => { const el = box.current; if (!el) return; const near = el.scrollHeight - el.scrollTop - el.clientHeight < 80; stick.current = near; setShowJump(!near); };
  const jump = () => { const el = box.current; if (el) { el.scrollTop = el.scrollHeight; stick.current = true; setShowJump(false); } };
  useEffect(() => { const el = ta.current; if (el) { el.style.height = "auto"; el.style.height = `${Math.min(el.scrollHeight, 160)}px`; } }, [text]);
  useEffect(() => () => ac.current?.abort(), []);                                  // leaving the page cancels generation (and stops token spend)

  const patchLast = useCallback((fn: (m: Msg) => Msg) => setMsgs((all) => all.map((m, i) => (i === all.length - 1 ? fn(m) : m))), []);
  async function run(question: string, history: Msg[]) {
    setPreErr(null); setBusy(true); stick.current = true;
    setMsgs([...history, { id: mid(), role: "user", content: question, state: "done" }, { id: mid(), role: "assistant", content: "", state: "streaming" }]);
    ac.current = new AbortController();
    try {
      await streamChat({ message: question, conversation_id: conv, project_id: current?.id ?? null }, {
        onMeta: (id) => setConv(id), onDelta: (d) => patchLast((m) => ({ ...m, content: m.content + d })), onTool: (name, ok) => patchLast((m) => ({ ...m, tools: [...(m.tools ?? []), ok ? name : `${name} (failed)`] })),
        onReplace: (txt) => patchLast((m) => ({ ...m, content: txt, notice: "Some claims could not be verified, so this answer was replaced by verified text." })),
        onDone: (d: ChatDone) => { /* the real cause (model unavailable) wins over the generic "replaced" notice */ patchLast((m) => ({ ...m, state: "done", sources: d.sources, notice: d.degraded ? "The AI model was unavailable, so this answer comes from verified notes only." : m.notice })); setAnnounce("Answer complete"); void qc.invalidateQueries({ queryKey: ["ai-convs"] }); },
        onError: (e) => patchLast((m) => ({ ...m, state: m.content ? "stopped" : "error", error: e.message || "The answer could not be completed." })),
      }, ac.current.signal, lang);
    } catch (e) {
      if (ac.current.signal.aborted) patchLast((m) => ({ ...m, state: "stopped" }));
      else { setPreErr(e); setMsgs(history); setText(question); }
    }
    setBusy(false);
  }
  const send = () => { const q = text.trim(); if (!q || busy || q.length < 2) return; setText(""); void run(q, msgs.filter((m) => m.state !== "error")); };
  const retry = () => { const lastUser = [...msgs].reverse().find((m) => m.role === "user"); if (lastUser) void run(lastUser.content, msgs.slice(0, msgs.lastIndexOf(lastUser))); };
  async function open(id: string) {
    ac.current?.abort();
    try { const r = await api<{ id: string; messages: ConvMessage[] }>(`ai/conversations/${id}`); setConv(id); setMsgs(r.messages.map((m) => ({ id: m.id, role: m.role, content: m.content, state: m.meta?.interrupted ? "stopped" : "done", sources: m.meta?.sources, tools: m.meta?.tools, notice: m.meta?.degraded ? "Answered from verified notes only." : undefined }))); jump(); }
    catch (e) { toast({ kind: "error", title: friendly(e, t).message }); }
  }
  const del = useApiMutation((id: string) => api(`ai/conversations/${id}`, { method: "DELETE" }), { invalidate: [["ai-convs"]], onSuccess: () => toast({ kind: "success", title: "Conversation deleted" }) });
  const fresh = () => { ac.current?.abort(); setMsgs([]); setConv(null); setText(""); setPreErr(null); };
  const copy = async (s: string) => { try { await navigator.clipboard.writeText(s); toast({ kind: "success", title: "Copied" }); } catch { toast({ kind: "error", title: "Could not copy" }); } };

  return (
    <div className="chat">
      <aside className="chat-side card" aria-label="Conversations">
        <Button variant="primary" onClick={fresh} style={{ width: "100%" }}><Plus size={16} aria-hidden />{t("assistant.new")}</Button>
        <ul className="list">{convs.data?.map((c) => (
          <li key={c.id} className="row" style={{ flexWrap: "nowrap", gap: ".25rem" }}>
            <button className="btn ghost sm grow" style={{ justifyContent: "flex-start", textAlign: "left", fontWeight: c.id === conv ? 700 : 500 }} aria-current={c.id === conv} onClick={() => void open(c.id)}><MessageSquare size={14} aria-hidden /><span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.title || "Untitled"}</span></button>
            <Button variant="ghost" size="sm" icon aria-label={`Delete conversation ${c.title}`} onClick={async () => { if (await confirm({ title: "Delete conversation?", message: "This can't be undone.", confirmLabel: t("common.delete"), danger: true })) { del.mutate(c.id); if (c.id === conv) fresh(); } }}><Trash2 size={14} aria-hidden /></Button></li>))}
          {convs.data?.length === 0 && <li className="hint">No conversations yet</li>}</ul>
      </aside>
      <section className="card chat-main chat-shell" aria-label="Chat">
        <div className="msgs" ref={box} onScroll={onScroll} role="log" aria-live="off" aria-busy={busy}>
          {status.data && !status.data.enabled && <Alert tone="info">{t("assistant.notConnected")}</Alert>}
          {msgs.length === 0 && <EmptyState bare icon={<MessageSquare size={32} aria-hidden />} title="Ask about your concrete" hint="Answers cite IS-code notes and your project's records. Verdicts always come from the rules engine." action={<div className="stack-sm" style={{ width: "100%" }}>{STARTERS.map((s) => <button key={s} className="btn sm" style={{ textAlign: "left", justifyContent: "flex-start", height: "auto", minHeight: 40, padding: ".45rem .7rem", fontWeight: 500 }} onClick={() => void run(s, [])}>{s}</button>)}</div>} />}
          {msgs.map((m, i) => (
            <div key={m.id} className={`msg ${m.role === "user" ? "user" : m.state === "error" ? "ai error" : "ai"}`}>
              <div className="small muted">{m.role === "user" ? "You" : "Assistant"}</div>
              <div className={`bubble ${m.state === "streaming" ? "cursor" : ""}`}>
                {m.state === "streaming" && !m.content && <span className="muted">Thinking…</span>}
                {m.role === "user" ? <span style={{ whiteSpace: "pre-wrap" }}>{m.content}</span> : <RichText text={m.content} sources={m.sources} />}
                {m.state === "error" && <p role="alert">✕ {m.error}</p>}{m.state === "stopped" && <p className="small muted">⏹ {m.error ?? "Stopped"}. {m.content ? "This is a partial answer." : "No text was generated yet."}</p>}
              </div>
              {m.tools && m.tools.length > 0 && <div className="row">{[...new Set(m.tools)].map((x) => <span key={x} className="chip">{TOOL_LABEL[x] ?? x.replaceAll("_", " ")}</span>)}</div>}
              {m.notice && <div className="small muted">ℹ {m.notice}</div>}
              {m.sources && m.sources.length > 0 && <details className="small"><summary style={{ cursor: "pointer" }}>{m.sources.length} source{m.sources.length > 1 ? "s" : ""}</summary><ul className="list">{m.sources.map((s) => <li key={s.label}><span className="chip">{s.label}</span> {s.title}{s.reference ? ` · ${s.reference}` : ""}</li>)}</ul></details>}
              {m.role === "assistant" && m.state !== "streaming" && m.state !== "error" && <div className="row">{m.content && <Button size="sm" variant="ghost" onClick={() => void copy(m.content)}><Copy size={14} aria-hidden />{t("common.copy")}</Button>}{i === msgs.length - 1 && !busy && <Button size="sm" variant="ghost" onClick={retry}><RefreshCw size={14} aria-hidden />{t("common.retry")}</Button>}</div>}
              {m.state === "error" && i === msgs.length - 1 && !busy && <div><Button size="sm" onClick={retry}><RefreshCw size={14} aria-hidden />{t("common.retry")}</Button></div>}
            </div>))}
        </div>
        <div className="sr-only" role="status" aria-live="polite">{announce}</div>
        {showJump && <Button className="jump" size="sm" onClick={jump}><ArrowDown size={14} aria-hidden />Jump to latest</Button>}
        <div>{preErr ? <div style={{ padding: ".5rem" }}><FormError error={preErr} /></div> : null}
          <form className="composer" onSubmit={(e) => { e.preventDefault(); send(); }}>
            <label className="sr-only" htmlFor="ask">{t("assistant.placeholder")}</label>
            <Textarea id="ask" ref={ta} rows={1} value={text} maxLength={max} placeholder={t("assistant.placeholder")} onChange={(e) => { setText(e.target.value); setAnnounce(""); }}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && window.matchMedia("(pointer: fine)").matches) { e.preventDefault(); send(); } }} />
            {busy ? <Button onClick={() => ac.current?.abort()} aria-label={t("assistant.stop")}><Square size={16} aria-hidden />{t("assistant.stop")}</Button> : <Button type="submit" variant="primary" disabled={text.trim().length < 2} aria-label={t("assistant.send")}><Send size={16} aria-hidden /><span className="only-desktop">{t("assistant.send")}</span></Button>}
          </form>
          {text.length > max * 0.8 && <div className="hint" style={{ padding: "0 .75rem .5rem" }}>{text.length}/{max}</div>}</div>
      </section>
    </div>
  );
}

function Knowledge() {
  const { current } = useProject(); const toast = useToast(); const confirm = useConfirm(); const [q, setQ] = useState(""); const dq = useDebounced(q.trim(), 450);
  type SearchRes = { results: { label: string; source: string; title: string; reference: string | null; text: string }[] };
  const [res, setRes] = useState<SearchRes | null>(null); const [ans, setAns] = useState<{ answer?: string; sources?: AiSource[] } | null>(null);
  const run = useApiMutation((v: string) => api<SearchRes>("ai/search", { method: "POST", body: { query: v, project_id: current?.id, top_k: 5 } }), { onSuccess: (r) => setRes(r) });
  const ask = useApiMutation((v: string) => api<{ answer?: string; sources?: AiSource[] }>("ai/ask", { method: "POST", body: { question: v, project_id: current?.id } }), { onSuccess: setAns });
  useEffect(() => { if (dq.length >= 2) run.mutate(dq); else setRes(null); }, [dq]); // eslint-disable-line react-hooks/exhaustive-deps
  const docs = useApiQuery<{ id: string; title: string; chunk_count: number }[]>(["ai-docs", current?.id], "ai/documents", { query: { project_id: current?.id }, enabled: !!current });
  const [d, setD] = useState({ title: "", text: "" });
  const addDoc = useApiMutation(() => api("ai/documents", { method: "POST", body: { project_id: current!.id, title: d.title.trim(), text: d.text } }), { invalidate: [["ai-docs"]], onSuccess: () => { setD({ title: "", text: "" }); toast({ kind: "success", title: "Document added to the assistant's knowledge" }); } });
  const delDoc = useApiMutation((id: string) => api(`ai/documents/${id}`, { method: "DELETE" }), { invalidate: [["ai-docs"]] });
  return (
    <div className="stack">
      <Card title="Search knowledge"><div className="stack-sm"><Field label="Search IS-code notes and project documents"><Input type="search" value={q} onChange={(e) => { setQ(e.target.value); setAns(null); }} /></Field>
        <div className="row"><Button loading={ask.isPending} disabled={q.trim().length < 3} onClick={() => ask.mutate(q.trim())}>Get a quick answer</Button>{run.isPending && <span className="hint">Searching…</span>}</div><FormError error={run.error ?? ask.error} />
        {ans && <Alert tone="info" title="Quick answer">{ans.answer}</Alert>}
        {res && (res.results.length === 0 ? <p className="muted">No matching passages.</p> : <ul className="list">{res.results.map((r) => <li key={r.label + r.title}><span className="chip">{r.label}</span> <strong>{r.title}</strong>{r.reference && <span className="hint"> · {r.reference}</span>}<div className="small">{r.text.slice(0, 320)}{r.text.length > 320 ? "…" : ""}</div></li>)}</ul>)}</div></Card>
      <Card title="Project documents the assistant can read">
        {docs.isLoading ? <SkeletonRows rows={2} /> : docs.error ? <ErrorState error={docs.error} compact onRetry={() => docs.refetch()} /> : !docs.data?.length ? <p className="muted">None yet. Paste a method statement or specification below.</p> : <ul className="list">{docs.data.map((x) => <li key={x.id} className="row between"><span>{x.title} <span className="hint">{x.chunk_count} passages</span></span><Button size="sm" onClick={async () => { if (await confirm({ title: "Remove document?", message: `“${x.title}” will no longer be used in answers.`, confirmLabel: "Remove", danger: true })) delDoc.mutate(x.id); }}>Remove</Button></li>)}</ul>}
        <form className="stack-sm" style={{ marginTop: ".75rem" }} onSubmit={(e) => { e.preventDefault(); addDoc.mutate(undefined); }}>
          <Field label="Title" required><Input value={d.title} onChange={(e) => setD({ ...d, title: e.target.value })} /></Field><Field label="Text" required hint="At least 20 characters. Plain text only."><Textarea value={d.text} onChange={(e) => setD({ ...d, text: e.target.value })} /></Field>
          <FormError error={addDoc.error ?? delDoc.error} /><div className="actions"><Button type="submit" variant="primary" loading={addDoc.isPending} disabled={d.title.trim().length < 2 || d.text.trim().length < 20}>Add document</Button></div></form>
      </Card>
    </div>
  );
}
export default function AssistantPage() {
  const { t } = useT(); const [tab, setTab] = useState("chat");
  return (
    <div className="stack assistant-page">
      <PageHeader title={t("assistant.title")} subtitle="Answers are grounded in IS-code notes and your records. Always confirm important decisions with an engineer." />
      <Tabs label="Assistant sections" value={tab} onChange={setTab} tabs={[{ id: "chat", label: "Chat" }, { id: "knowledge", label: "Knowledge" }]} />
      <TabPanel id="chat" value={tab}><Chat /></TabPanel><TabPanel id="knowledge" value={tab}><Knowledge /></TabPanel>
    </div>
  );
}
