"use client";
import { Building2 } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { useProject, useSession } from "@/components/Providers";
import { Field, Input } from "@/components/ui/form";
import { Modal, useToast } from "@/components/ui/overlay";
import { Button, Card, EmptyState, FormError, PageHeader, SkeletonRows } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { fmtDate } from "@/lib/format";
import { useApiMutation } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { can } from "@/lib/perm";
import type { Project } from "@/lib/types";

export default function ProjectsPage() {
  const { t, lang } = useT(); const { user } = useSession(); const { projects, loading, setCurrent } = useProject(); const toast = useToast();
  const [open, setOpen] = useState(false); const [f, setF] = useState({ name: "", location: "", client_name: "" });
  const create = useApiMutation(() => api<Project>("projects", { method: "POST", body: { name: f.name.trim(), ...(f.location ? { location: f.location } : {}), ...(f.client_name ? { client_name: f.client_name } : {}) } }), { invalidate: [["projects"]], onSuccess: (p) => { setOpen(false); setCurrent(p.id); toast({ kind: "success", title: `Project “${p.name}” created` }); } });
  return (
    <div className="stack">
      <PageHeader title={t("nav.projects")} actions={can(user, "write") ? <Button variant="primary" onClick={() => setOpen(true)}>New project</Button> : undefined} />
      {loading ? <SkeletonRows rows={3} /> : projects.length === 0 ? <EmptyState icon={<Building2 size={36} aria-hidden />} title="No projects found" hint="Create your first project to start registering concrete batches." action={can(user, "write") ? <Button variant="primary" onClick={() => setOpen(true)}>New project</Button> : undefined} /> : (
        <div className="grid cols-2">{projects.map((p) => <Card key={p.id} title={<Link href={`/projects/${p.id}`}>{p.name}</Link>}><p className="small muted" style={{ margin: 0 }}>{[p.location, p.client_name].filter(Boolean).join(" · ") || "No details"} · Created {fmtDate(p.created_at, lang)}</p></Card>)}</div>
      )}
      <Modal open={open} onClose={() => setOpen(false)} title="New project" footer={<><Button onClick={() => setOpen(false)}>{t("common.cancel")}</Button><Button variant="primary" loading={create.isPending} disabled={f.name.trim().length < 2} onClick={() => create.mutate(undefined)}>{t("common.create")}</Button></>}>
        <div className="stack"><Field label="Project name" required hint="At least 2 characters"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field><Field label="Location"><Input value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} /></Field><Field label="Client"><Input value={f.client_name} onChange={(e) => setF({ ...f, client_name: e.target.value })} /></Field><FormError error={create.error} /></div>
      </Modal>
    </div>
  );
}
