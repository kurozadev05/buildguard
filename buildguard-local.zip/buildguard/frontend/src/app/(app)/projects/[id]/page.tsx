"use client";
import { Printer } from "lucide-react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import { useSession } from "@/components/Providers";
import { Field, Input, Select } from "@/components/ui/form";
import { Modal, useToast } from "@/components/ui/overlay";
import { Alert, Badge, Button, Card, EmptyState, ErrorState, FormError, PageHeader, SkeletonRows, StatusBadge, TabPanel, Tabs } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { fmtDate } from "@/lib/format";
import { useApiMutation, useApiQuery } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { can } from "@/lib/perm";
import type { Project, Tree } from "@/lib/types";

type Add = { kind: "building" } | { kind: "floor"; buildingId: string } | { kind: "element"; floorId: string } | null;
interface Passport { generated_for: string; audit_chain_ok: boolean; note: string; batches: { batch_code: string; grade: string; supplier: string | null; delivery_date: string | null; status: string; quantity_m3: number; locations: string[]; tests: { type: string; age_days: number | null; status: string; record_hash: string }[] }[] }
export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>(); const { lang } = useT(); const { user } = useSession(); const toast = useToast(); const [tab, setTab] = useState("structure");
  const p = useApiQuery<Project>(["project", id], `projects/${id}`, { offline: false }); const tree = useApiQuery<Tree>(["tree", id], `projects/${id}/tree`, { offline: true });
  const members = useApiQuery<{ id: string; full_name: string; email: string; role: string }[]>(["members", id], `projects/${id}/members`, { enabled: tab === "members" });
  const pass = useApiQuery<Passport>(["passport", id], `projects/${id}/handover-passport`, { enabled: tab === "handover" });
  const users = useApiQuery<{ id: string; full_name: string; email: string }[]>(["users-pick"], "auth/users", { query: { limit: 100 }, enabled: tab === "members" && can(user, "admin") });
  const [add, setAdd] = useState<Add>(null); const [name, setName] = useState(""); const [level, setLevel] = useState("0"); const [etype, setEtype] = useState("slab"); const [uid, setUid] = useState("");
  const write = can(user, "write");
  const create = useApiMutation(() => {
    if (!add) throw new Error("no target");
    if (add.kind === "building") return api(`projects/${id}/buildings`, { method: "POST", body: { name: name.trim() } });
    if (add.kind === "floor") return api(`buildings/${add.buildingId}/floors`, { method: "POST", body: { name: name.trim(), level: Number(level) } });
    return api(`floors/${add.floorId}/elements`, { method: "POST", body: { name: name.trim(), element_type: etype } });
  }, { invalidate: [["tree"]], onSuccess: () => { setAdd(null); setName(""); toast({ kind: "success", title: "Added" }); } });
  const addMember = useApiMutation(() => api(`projects/${id}/members`, { method: "POST", body: { user_id: uid } }), { invalidate: [["members"]], onSuccess: () => { setUid(""); toast({ kind: "success", title: "Member added" }); } });
  if (p.isLoading) return <SkeletonRows rows={4} />; if (p.error || !p.data) return <ErrorState error={p.error} onRetry={() => p.refetch()} />;
  const B = ({ onClick, children }: { onClick: () => void; children: React.ReactNode }) => <Button size="sm" onClick={onClick}>{children}</Button>;
  return (
    <div className="stack">
      <PageHeader title={p.data.name} subtitle={[p.data.location, p.data.client_name].filter(Boolean).join(" · ")} />
      <Tabs label="Project sections" value={tab} onChange={setTab} tabs={[{ id: "structure", label: "Structure" }, { id: "members", label: "Team" }, { id: "handover", label: "Handover passport" }]} />
      <TabPanel id="structure" value={tab}>
        <Card title="Buildings, floors and elements" actions={write ? <Button size="sm" variant="primary" onClick={() => setAdd({ kind: "building" })}>Add building</Button> : undefined}>
          {tree.isLoading ? <SkeletonRows rows={3} /> : tree.error ? <ErrorState error={tree.error} compact onRetry={() => tree.refetch()} /> : !tree.data?.buildings.length ? <EmptyState title="No structure yet" hint="Add a building, then floors, then elements (slab, beam, column…) so batches can be traced to where they were poured." /> : (
            <ul className="list">{tree.data.buildings.map((b) => (
              <li key={b.id}><div className="row between"><strong>{b.name}</strong>{write && <B onClick={() => setAdd({ kind: "floor", buildingId: b.id })}>Add floor</B>}</div>
                <ul className="list" style={{ paddingLeft: "1rem" }}>{b.floors.map((f) => <li key={f.id}><div className="row between"><span>{f.name} <span className="hint">(level {f.level})</span></span>{write && <B onClick={() => setAdd({ kind: "element", floorId: f.id })}>Add element</B>}</div>
                  <div className="row" style={{ marginTop: 4 }}>{f.elements.length === 0 ? <span className="hint">No elements</span> : f.elements.map((e) => <Badge key={e.id}>{e.name} · {e.element_type}</Badge>)}</div></li>)}</ul></li>))}</ul>)}
        </Card>
      </TabPanel>
      <TabPanel id="members" value={tab}>
        <Card title="Project team">{members.isLoading ? <SkeletonRows rows={2} /> : members.error ? <ErrorState error={members.error} compact onRetry={() => members.refetch()} /> : <ul className="list">{members.data?.map((m) => <li key={m.id}><strong>{m.full_name}</strong> <span className="hint">{m.email} · {m.role.replace("_", " ")}</span></li>)}</ul>}
          {can(user, "admin") && <div className="row" style={{ marginTop: ".75rem", alignItems: "flex-end" }}><Field label="Add a user" className="grow"><Select value={uid} onChange={(e) => setUid(e.target.value)}><option value="">Choose…</option>{users.data?.filter((u) => !members.data?.some((m) => m.id === u.id)).map((u) => <option key={u.id} value={u.id}>{u.full_name} ({u.email})</option>)}</Select></Field><Button variant="primary" disabled={!uid} loading={addMember.isPending} onClick={() => addMember.mutate(undefined)}>Add</Button></div>}<FormError error={addMember.error} /></Card>
      </TabPanel>
      <TabPanel id="handover" value={tab}>
        {pass.isLoading ? <SkeletonRows rows={4} /> : pass.error ? <ErrorState error={pass.error} onRetry={() => pass.refetch()} /> : pass.data && (
          <div className="stack">
            <div className="row between no-print"><Alert tone={pass.data.audit_chain_ok ? "success" : "danger"}>{pass.data.audit_chain_ok ? "✓ Audit chain intact at time of generation." : "✕ Audit chain check failed."}</Alert><Button onClick={() => window.print()}><Printer size={16} aria-hidden />Print / save as PDF</Button></div>
            {pass.data.batches.map((b) => <Card key={b.batch_code} title={<span>{b.batch_code} · {b.grade}</span>} actions={<StatusBadge status={b.status} />}><p className="small muted" style={{ marginTop: 0 }}>{b.supplier ?? "—"} · {b.quantity_m3} m³ · Delivered {fmtDate(b.delivery_date, lang)}</p>{b.locations.length > 0 && <p className="small">Used in: {b.locations.join("; ")}</p>}
              <ul className="list">{b.tests.map((t, i) => <li key={i} className="small">{t.type.replaceAll("_", " ")}{t.age_days ? ` (${t.age_days} d)` : ""} <StatusBadge status={t.status} /> <span className="mono">{t.record_hash.slice(0, 12)}…</span></li>)}</ul></Card>)}
            <p className="hint">{pass.data.note} Generated for {pass.data.generated_for}.</p>
          </div>)}
      </TabPanel>
      <Modal open={!!add} onClose={() => setAdd(null)} title={add?.kind === "building" ? "Add building" : add?.kind === "floor" ? "Add floor" : "Add element"} footer={<><Button onClick={() => setAdd(null)}>Cancel</Button><Button variant="primary" loading={create.isPending} disabled={!name.trim()} onClick={() => create.mutate(undefined)}>Add</Button></>}>
        <div className="stack"><Field label="Name" required><Input value={name} onChange={(e) => setName(e.target.value)} /></Field>
          {add?.kind === "floor" && <Field label="Level" hint="0 = ground, 1 = first floor, -1 = basement"><Input type="number" value={level} onChange={(e) => setLevel(e.target.value)} /></Field>}
          {add?.kind === "element" && <Field label="Element type"><Select value={etype} onChange={(e) => setEtype(e.target.value)}>{["slab", "beam", "column", "footing", "wall", "staircase", "raft", "other"].map((x) => <option key={x}>{x}</option>)}</Select></Field>}<FormError error={create.error} /></div>
      </Modal>
      <p className="hint no-print"><Link href="/projects">← All projects</Link></p>
    </div>
  );
}
