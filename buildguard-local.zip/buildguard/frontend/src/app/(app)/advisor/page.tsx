"use client";
import { useState } from "react";
import { Field, Input, Select } from "@/components/ui/form";
import { Alert, Badge, Button, Card, FormError, PageHeader } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { useApiMutation, useApiQuery, useDebounced } from "@/lib/hooks";
import { useT } from "@/lib/i18n";

interface Item { key: string; test_type: string | null; mandatory: boolean; name: string; name_hi: string; purpose: string; purpose_hi: string; timing: string; frequency: string; evidence: string[]; reference: string }
interface Checklist { sample_plan: { required_samples: number; cubes_per_sample: number }; items: Item[]; disclaimer: string; explanation?: string }
export default function AdvisorPage() {
  const { lang } = useT(); const [f, setF] = useState({ construction_type: "rcc", element_type: "slab", grade: "M25", exposure: "moderate", quantity_m3: "10", reinforcement: "light", placing_method: "normal", weather: "normal", cement_type: "opc" });
  const [kq, setKq] = useState(""); const kd = useDebounced(kq.trim(), 400);
  const run = useApiMutation((explain: boolean) => api<Checklist>("advisor/checklist", { method: "POST", query: { lang }, body: { ...f, quantity_m3: Number(f.quantity_m3), explain } }));
  const know = useApiQuery<{ id: string; title: string; text: string; reference?: string }[]>(["knowledge"], "advisor/knowledge", { query: { q: kd, limit: 5 }, enabled: kd.length >= 2 });
  const s = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const opt = (a: string[]) => a.map((x) => <option key={x} value={x}>{x.replaceAll("_", " ")}</option>);
  return (
    <div className="stack">
      <PageHeader title="Test advisor" subtitle="What to test, when, and how many samples, for a planned pour." />
      <form className="card stack" onSubmit={(e) => { e.preventDefault(); run.mutate(false); }}>
        <div className="form-grid two">
          <Field label="Grade" required><Select value={f.grade} onChange={s("grade")}>{opt(["M15", "M20", "M25", "M30", "M35", "M40"])}</Select></Field>
          <Field label="Quantity (m³)" required><Input type="number" min="0.5" step="any" value={f.quantity_m3} onChange={s("quantity_m3")} /></Field>
          <Field label="Element"><Select value={f.element_type} onChange={s("element_type")}>{opt(["slab", "beam", "column", "footing", "wall", "staircase", "raft", "other"])}</Select></Field>
          <Field label="Construction"><Select value={f.construction_type} onChange={s("construction_type")}>{opt(["rcc", "pcc"])}</Select></Field>
          <Field label="Exposure"><Select value={f.exposure} onChange={s("exposure")}>{opt(["mild", "moderate", "severe", "very_severe", "extreme"])}</Select></Field>
          <Field label="Reinforcement"><Select value={f.reinforcement} onChange={s("reinforcement")}>{opt(["light", "heavy"])}</Select></Field>
          <Field label="Placing method"><Select value={f.placing_method} onChange={s("placing_method")}>{opt(["normal", "pumped", "tremie"])}</Select></Field>
          <Field label="Weather"><Select value={f.weather} onChange={s("weather")}>{opt(["normal", "hot", "cold"])}</Select></Field>
        </div>
        <FormError error={run.error} /><div className="actions"><Button onClick={() => run.mutate(true)} loading={run.isPending}>Plain-language summary</Button><Button type="submit" variant="primary" loading={run.isPending}>Get checklist</Button></div>
      </form>
      {run.data && <Card title="Your checklist" actions={<Badge tone="info">{run.data.sample_plan.required_samples} samples · {run.data.sample_plan.cubes_per_sample} cubes each</Badge>}>
        {run.data.explanation && <Alert tone="info">{run.data.explanation}</Alert>}
        <ol className="list" style={{ paddingLeft: "1.2rem" }}>{run.data.items.map((i) => <li key={i.key} style={{ display: "list-item" }}><strong>{lang === "hi" ? i.name_hi : i.name}</strong> {i.mandatory ? <Badge tone="warning">Required</Badge> : <Badge>Optional</Badge>}<div className="small">{lang === "hi" ? i.purpose_hi : i.purpose}</div><div className="small muted">{i.timing} · {i.frequency} · {i.reference}</div>{i.evidence.length > 0 && <div className="small">Keep: {i.evidence.join(", ")}</div>}</li>)}</ol><p className="hint">{run.data.disclaimer}</p></Card>}
      <Card title="Search the IS-code notes"><Field label="Ask about a requirement" hint="e.g. curing, minimum cement, cover"><Input type="search" value={kq} onChange={(e) => setKq(e.target.value)} /></Field>
        {know.isFetching && <p className="hint">Searching…</p>}{know.data?.length === 0 && <p className="muted">No notes found.</p>}<ul className="list">{know.data?.map((k) => <li key={k.id ?? k.title}><strong>{k.title}</strong><div className="small">{k.text}</div>{k.reference && <div className="hint">{k.reference}</div>}</li>)}</ul></Card>
    </div>
  );
}
