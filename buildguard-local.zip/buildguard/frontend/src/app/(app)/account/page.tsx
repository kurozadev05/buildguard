"use client";
import { useEffect, useState } from "react";
import { useSession } from "@/components/Providers";
import { Field, Input, Select } from "@/components/ui/form";
import { useConfirm, useToast } from "@/components/ui/overlay";
import { Alert, Button, Card, FormError, Kv, PageHeader } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { useApiMutation, useApiQuery } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { clearOfflineData } from "@/lib/offline/snapshots";

interface BIPEvent extends Event { prompt: () => Promise<void> }
export default function AccountPage() {
  const { user, logout } = useSession(); const { t, lang, setLang } = useT(); const toast = useToast(); const confirm = useConfirm();
  const [f, setF] = useState({ current: "", next: "", again: "" }); const [touched, setTouched] = useState(false); const [inst, setInst] = useState<BIPEvent | null>(null);
  useEffect(() => { const h = (e: Event) => { e.preventDefault(); setInst(e as BIPEvent); }; window.addEventListener("beforeinstallprompt", h); return () => window.removeEventListener("beforeinstallprompt", h); }, []);
  const me = useApiQuery<Record<string, unknown>>(["ai-usage-me"], "ai/usage/me");
  const change = useApiMutation(() => api("auth/change-password", { method: "POST", body: { current_password: f.current, new_password: f.next } }), { onSuccess: () => { toast({ kind: "success", title: "Password changed", message: "For security you have been signed out everywhere. Please sign in again." }); setTimeout(() => window.location.assign("/login"), 1200); } });
  const errs = { current: f.current ? "" : "Enter your current password", next: f.next.length < 10 ? "Use at least 10 characters" : f.next === f.current ? "Choose a different password" : "", again: f.again === f.next ? "" : "Passwords do not match" };
  if (!user) return null;
  return (
    <div className="stack">
      <PageHeader title={t("nav.account")} />
      <div className="grid cols-2">
        <Card title="Profile"><Kv items={[["Name", user.full_name], ["Email", user.email], ["Role", user.role.replace("_", " ")]]} /></Card>
        <Card title="Preferences"><Field label={t("common.language")} hint="Hindi coverage is partial: labels the server provides are translated too."><Select value={lang} onChange={(e) => setLang(e.target.value as "en" | "hi")}><option value="en">English</option><option value="hi">हिन्दी</option></Select></Field></Card>
      </div>
      <Card title="Change password">
        <form className="stack" noValidate onSubmit={(e) => { e.preventDefault(); setTouched(true); if (!Object.values(errs).some(Boolean)) change.mutate(undefined); }}>
          <Field label="Current password" required error={touched ? errs.current : undefined}><Input type="password" autoComplete="current-password" value={f.current} onChange={(e) => setF({ ...f, current: e.target.value })} /></Field>
          <Field label="New password" required hint="At least 10 characters" error={touched ? errs.next : undefined}><Input type="password" autoComplete="new-password" value={f.next} onChange={(e) => setF({ ...f, next: e.target.value })} /></Field>
          <Field label="Repeat new password" required error={touched ? errs.again : undefined}><Input type="password" autoComplete="new-password" value={f.again} onChange={(e) => setF({ ...f, again: e.target.value })} /></Field>
          <FormError error={change.error} /><div className="actions"><Button type="submit" variant="primary" loading={change.isPending}>Change password</Button></div>
        </form>
      </Card>
      <Card title="This device">
        <div className="stack-sm"><p className="small muted" style={{ margin: 0 }}>Recently viewed lists and pending changes are kept on this device so the app works offline. They are removed when you sign out.</p>
          <div className="row">{inst && <Button variant="primary" onClick={async () => { await inst.prompt(); setInst(null); }}>Install app</Button>}
            <Button onClick={async () => { if (await confirm({ title: "Clear offline data?", message: "Saved lists and any changes still waiting to sync are deleted from this device.", confirmLabel: "Clear", danger: true })) { await clearOfflineData(); toast({ kind: "success", title: "Offline data cleared" }); } }}>Clear offline data</Button>
            <Button variant="danger" onClick={() => void logout()}>{t("common.signOut")}</Button></div></div>
      </Card>
      {me.data && <Card title="Your assistant usage today"><pre className="mono" style={{ margin: 0, overflowX: "auto" }} tabIndex={0}>{JSON.stringify(me.data, null, 2)}</pre></Card>}
      {!inst && <Alert tone="info">To install: use your browser menu → “Install app” / “Add to Home Screen”.</Alert>}
    </div>
  );
}
