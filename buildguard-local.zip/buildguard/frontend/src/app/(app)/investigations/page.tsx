"use client";
import { Suspense } from "react";
import { DataTable } from "@/components/ui/DataTable";
import { Field, Select } from "@/components/ui/form";
import { Badge, Button, EmptyState, ErrorState, PageHeader, Progress, SkeletonRows } from "@/components/ui/ui";
import { fmtDate } from "@/lib/format";
import { useInfiniteApi } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import type { Investigation } from "@/lib/types";
import { useUrlParams } from "@/lib/urlstate";

function Inner() {
  const { t, lang } = useT(); const [f, setF] = useUrlParams(["status"] as const);
  const q = useInfiniteApi<Investigation>(["investigations"], "investigations", { status: f.status }, 20, { offline: true });
  return (
    <div className="stack">
      <PageHeader title={t("nav.investigations")} subtitle="Staged action plans for batches with failing or doubtful results." />
      <div className="card"><Field plain label={t("common.status")}><Select value={f.status} onChange={(e) => setF({ status: e.target.value })}><option value="">{t("common.all")}</option><option value="open">Open</option><option value="closed">Closed</option></Select></Field></div>
      {q.isLoading ? <SkeletonRows /> : q.error ? <ErrorState error={q.error} onRetry={() => q.refetch()} /> : q.items.length === 0 ? <EmptyState title={f.status ? "No investigations match" : "No investigations"} hint="They open when a batch is flagged, or when an engineer opens one." action={f.status ? <Button onClick={() => setF({ status: "" })}>{t("common.clear")}</Button> : undefined} /> : (
        <>
          <DataTable<Investigation> caption="Investigations" rowKey={(r) => r.id} href={(r) => `/investigations/${r.id}`} rows={q.items} columns={[
            { key: "b", header: "Batch", cell: (r) => <strong>{r.batch_code}</strong> }, { key: "s", header: t("common.status"), cell: (r) => <Badge tone={r.status === "open" ? "warning" : "success"}>{r.status === "open" ? "⚠ Open" : "✓ Closed"}</Badge> },
            { key: "p", header: "Progress", cell: (r) => <div style={{ minWidth: 120 }}><Progress value={r.progress.done} max={r.progress.total} label={`${r.progress.done} of ${r.progress.total} actions`} /><span className="hint">{r.progress.done}/{r.progress.total} actions</span></div> },
            { key: "r", header: "Reason", cell: (r) => <span style={{ overflowWrap: "anywhere" }}>{r.reason}</span> }, { key: "o", header: "Opened", cell: (r) => fmtDate(r.opened_at, lang) } ]} />
          {q.hasNextPage && <div className="row" style={{ justifyContent: "center" }}><Button onClick={() => q.fetchNextPage()} loading={q.isFetchingNextPage}>{t("common.loadMore")}</Button></div>}
        </>
      )}
    </div>
  );
}
export default function Page() { return <Suspense fallback={<SkeletonRows />}><Inner /></Suspense>; }
