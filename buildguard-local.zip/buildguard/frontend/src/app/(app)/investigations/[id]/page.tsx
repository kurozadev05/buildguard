"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import { useSession } from "@/components/Providers";
import { Field, Input, Textarea } from "@/components/ui/form";
import { Modal, useToast } from "@/components/ui/overlay";
import { Alert, Badge, Button, Card, ErrorState, FormError, PageHeader, Progress, SkeletonRows } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { fmtDateTime } from "@/lib/format";
import { useApiMutation, useApiQuery } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { can } from "@/lib/perm";
import type { Action, Investigation } from "@/lib/types";

const TONE = { pending: "warning", done: "success", waived: "neutral" } as const; const MARK = { pending: "⚠ Pending", done: "✓ Done", waived: "— Waived" } as const;
export default function InvestigationDetail() {
  const { id } = useParams<{ id: string }>(); const { t, lang } = useT(); const { user } = useSession(); const toast = useToast();
  const q = useApiQuery<Investigation>(["investigation", id], `investigations/${id}`, { offline: true });
  const [note, setNote] = useState<{ action: Action; status: "done" | "waived" } | null>(null); const [text, setText] = useState(""); const [closing, setClosing] = useState(false); const [closure, setClosure] = useState("");
  const patch = useApiMutation((v: { id: string; status: string; note?: string }) => api(`investigations/actions/${v.id}`, { method: "PATCH", body: { status: v.status, ...(v.note ? { note: v.note } : {}) } }), { invalidate: [["investigation"], ["investigations"], ["dashboard"]], onSuccess: () => { setNote(null); setText(""); toast({ kind: "success", title: "Action updated" }); } });
  const close = useApiMutation(() => api(`investigations/${id}/close`, { method: "POST", body: { closure_note: closure } }), { invalidate: [["investigation"], ["investigations"], ["dashboard"], ["batch"]], onSuccess: () => { setClosing(false); toast({ kind: "success", title: "Investigation closed" }); } });
  if (q.isLoading) return <SkeletonRows rows={5} />; if (q.error || !q.data) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  const v = q.data; const canAct = can(user, "review") && v.status === "open"; const stages = [...new Set(v.actions.map((a) => a.stage))].sort();
  return (
    <div className="stack">
      <PageHeader title={`Investigation: ${v.batch_code}`} subtitle={<span className="row"><Badge tone={v.status === "open" ? "warning" : "success"}>{v.status === "open" ? "⚠ Open" : "✓ Closed"}</Badge><span>Opened {fmtDateTime(v.opened_at, lang)}</span></span>} actions={<Link className="btn" href={`/batches/${v.batch_id}`}>Open batch</Link>} />
      <Card><p style={{ marginTop: 0 }}>{v.reason}</p><Progress value={v.progress.done} max={v.progress.total} label="Actions completed" /><p className="hint">{v.progress.done} of {v.progress.total} actions complete. Steps are guidance from the rules; an engineer decides.</p>{v.closure_note && <Alert tone="success" title="Closed">{v.closure_note}</Alert>}</Card>
      {stages.map((s) => (
        <Card key={s} title={`Stage ${s}`}>
          <ul className="list">{v.actions.filter((a) => a.stage === s).map((a) => (
            <li key={a.id}><div className="row between"><strong>{a.description}</strong><Badge tone={TONE[a.status]}>{MARK[a.status]}</Badge></div>
              <div className="small muted">{a.reference}{a.path ? ` · ${a.path}` : ""}</div>{a.note && <div className="small">Note: {a.note}</div>}
              {canAct && a.status === "pending" && <div className="row" style={{ marginTop: ".4rem" }}>
                {a.action_type.includes("test") && <Link className="btn sm" href={`/tests/new?batch=${v.batch_id}&action=${a.id}`}>Record result</Link>}
                <Button size="sm" onClick={() => { setNote({ action: a, status: "done" }); setText(""); }}>Mark done</Button><Button size="sm" variant="ghost" onClick={() => { setNote({ action: a, status: "waived" }); setText(""); }}>Waive</Button></div>}</li>))}</ul>
        </Card>
      ))}
      {canAct && <div className="actions"><Button variant="primary" onClick={() => setClosing(true)}>Close investigation</Button></div>}
      <Modal open={!!note} onClose={() => setNote(null)} title={note?.status === "waived" ? "Waive this action" : "Mark action done"} footer={<><Button onClick={() => setNote(null)}>{t("common.cancel")}</Button><Button variant="primary" loading={patch.isPending} disabled={note?.status === "waived" && text.trim().length < 3} onClick={() => patch.mutate({ id: note!.action.id, status: note!.status, note: text.trim() || undefined })}>Save</Button></>}>
        <div className="stack"><p>{note?.action.description}</p><Field label={note?.status === "waived" ? "Why is this being waived?" : "Note"} required={note?.status === "waived"}><Textarea value={text} onChange={(e) => setText(e.target.value)} /></Field><FormError error={patch.error} /></div>
      </Modal>
      <Modal open={closing} onClose={() => setClosing(false)} title="Close investigation" footer={<><Button onClick={() => setClosing(false)}>{t("common.cancel")}</Button><Button variant="primary" loading={close.isPending} disabled={closure.trim().length < 5} onClick={() => close.mutate(undefined)}>Close</Button></>}>
        <div className="stack"><Field label="Closure note" required hint="Summarise the finding and decision (min. 5 characters)"><Input value={closure} onChange={(e) => setClosure(e.target.value)} /></Field><FormError error={close.error} /></div>
      </Modal>
    </div>
  );
}
