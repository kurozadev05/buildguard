"use client";
import { RefreshCw } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { useSession } from "@/components/Providers";
import { useConfirm, useToast } from "@/components/ui/overlay";
import { Alert, Badge, Button, EmptyState, PageHeader } from "@/components/ui/ui";
import { friendly } from "@/lib/errors";
import { fmtDateTime } from "@/lib/format";
import { useOnline } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { discard, flushQueue, listQueue, retryFailed, subscribeQueue, type QueuedOp } from "@/lib/offline/queue";

export default function SyncPage() {
  const { user } = useSession(); const { t, lang } = useT(); const online = useOnline(); const toast = useToast(); const confirm = useConfirm();
  const [ops, setOps] = useState<QueuedOp[]>([]); const [busy, setBusy] = useState(false);
  const load = useCallback(() => { if (user) void listQueue(user.id).then(setOps); }, [user]);
  useEffect(() => { load(); return subscribeQueue(load); }, [load]);
  async function syncNow() {
    if (!user) return; setBusy(true);
    try { await retryFailed(user.id); const s = await flushQueue(user.id); toast({ kind: s.remaining || s.failed ? "warning" : "success", title: `${s.applied + s.duplicates} confirmed by server`, message: s.failed ? `${s.failed} rejected.` : s.remaining ? `${s.remaining} still waiting.` : undefined }); }
    catch (e) { toast({ kind: "error", title: friendly(e, t).message }); } setBusy(false);
  }
  return (
    <div className="stack">
      <PageHeader title="Pending changes" subtitle="Changes made offline stay here until the server confirms them." actions={<Button variant="primary" loading={busy} disabled={!online || !ops.length} onClick={syncNow}><RefreshCw size={16} aria-hidden />Sync now</Button>} />
      {!online && <Alert tone="warning">You are offline. These will be sent automatically when you reconnect.</Alert>}
      {ops.length === 0 ? <EmptyState title="Everything is synced" hint="✓ No changes are waiting on this device." /> : (
        <div className="card"><ul className="list">{ops.map((o) => (
          <li key={o.op_id} className="row between"><div className="grow"><strong>{o.label}</strong> <Badge tone={o.status === "failed" ? "danger" : "warning"}>{o.status === "failed" ? "✕ Rejected" : "⚠ Waiting for server"}</Badge>
            <div className="hint">Saved {fmtDateTime(o.client_ts, lang)} · attempts {o.attempts}</div>{o.error && <div className="err-text">Server said: {o.error}</div>}</div>
            <Button size="sm" onClick={async () => { if (await confirm({ title: "Discard this change?", message: "It has not been saved on the server and will be lost.", confirmLabel: "Discard", danger: true })) void discard(o.op_id); }}>Discard</Button></li>))}</ul></div>
      )}
    </div>
  );
}
