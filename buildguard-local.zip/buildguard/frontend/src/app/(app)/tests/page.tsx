"use client";
import { Suspense } from "react";
import { DataTable } from "@/components/ui/DataTable";
import { Field, Select } from "@/components/ui/form";
import { Button, EmptyState, ErrorState, LinkButton, PageHeader, SkeletonRows, StaleNote, StatusBadge } from "@/components/ui/ui";
import { useSession } from "@/components/Providers";
import { fmtDateTime, TEST_LABEL } from "@/lib/format";
import { useInfiniteApi } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { can } from "@/lib/perm";
import type { TestRec } from "@/lib/types";
import { useUrlParams } from "@/lib/urlstate";

function Inner() {
  const { t, lang } = useT(); const { user } = useSession(); const [f, setF] = useUrlParams(["status", "batch", "all"] as const);
  const q = useInfiniteApi<TestRec>(["tests"], "tests", { status: f.status, batch_id: f.batch, current_only: f.all ? false : true, lang }, 20, { offline: true });
  return (
    <div className="stack">
      <PageHeader title={t("nav.tests")} actions={can(user, "test") ? <LinkButton href="/tests/new" variant="primary">Record result</LinkButton> : undefined} />
      <div className="card filters">
        <Field plain label={t("common.status")}><Select value={f.status} onChange={(e) => setF({ status: e.target.value })}><option value="">{t("common.all")}</option>{["VERIFIED", "REVIEW_REQUIRED", "FLAGGED", "PENDING"].map((s) => <option key={s} value={s}>{t(`status.${s}`)}</option>)}</Select></Field>
        <Field plain label="Versions"><Select value={f.all} onChange={(e) => setF({ all: e.target.value })}><option value="">Latest version only</option><option value="1">Include amended (older) versions</option></Select></Field>
      </div>
      <StaleNote at={q.savedAt} />
      {q.isLoading ? <SkeletonRows /> : q.error ? <ErrorState error={q.error} onRetry={() => q.refetch()} /> : q.items.length === 0 ? <EmptyState title="No test results" hint={f.status ? "Nothing matches this filter." : "Record a result after a sample is tested."} action={f.status ? <Button onClick={() => setF({ status: "" })}>{t("common.clear")}</Button> : undefined} /> : (
        <>
          <DataTable<TestRec> caption="Test results" rowKey={(r) => r.id} href={(r) => `/tests/${r.id}`} rows={q.items} columns={[
            { key: "t", header: "Test", cell: (r) => <strong>{TEST_LABEL[r.test_type] ?? r.test_type}</strong> }, { key: "b", header: "Batch", cell: (r) => r.batch_code ?? "—" }, { key: "a", header: "Age", cell: (r) => (r.age_days ? `${r.age_days} d` : "—") },
            { key: "s", header: t("common.status"), cell: (r) => <StatusBadge status={r.status} /> }, { key: "v", header: "Version", cell: (r) => `v${r.version}${r.is_current === false ? " (older)" : ""}` }, { key: "d", header: "Tested", cell: (r) => fmtDateTime(r.tested_at, lang) } ]} />
          {q.hasNextPage && <div className="row" style={{ justifyContent: "center" }}><Button onClick={() => q.fetchNextPage()} loading={q.isFetchingNextPage}>{t("common.loadMore")}</Button></div>}
        </>
      )}
    </div>
  );
}
export default function Page() { return <Suspense fallback={<SkeletonRows />}><Inner /></Suspense>; }
