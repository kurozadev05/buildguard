"use client";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { RequireCap } from "@/components/AppShell";
import { useProject, useSession } from "@/components/Providers";
import { buildValues, TEST_TYPES, TestFields, type TState } from "@/components/TestFields";
import { Field, Input, Select, Textarea } from "@/components/ui/form";
import { useToast } from "@/components/ui/overlay";
import { Alert, Button, FormError, PageHeader, SkeletonRows } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { friendly } from "@/lib/errors";
import { uuid } from "@/lib/format";
import { useApiQuery } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { submitOrQueue } from "@/lib/offline/queue";
import type { Batch, Sample, TestRec } from "@/lib/types";

function Inner() {
  const { t } = useT(); const router = useRouter(); const sp = useSearchParams(); const toast = useToast(); const { user } = useSession(); const { current } = useProject();
  const [batchId, setBatchId] = useState(sp.get("batch") ?? ""); const [sampleId, setSampleId] = useState(sp.get("sample") ?? "");
  const [type, setType] = useState("cube_compressive_strength");
  const prefill = sp.get("spec1");                                              // from a machine-display photo reading: first specimen only
  const [s, setS] = useState<TState>({ age_days: sp.get("age") ?? "28", ...(prefill ? { s1: prefill } : {}) });
  const [lab, setLab] = useState(""); const [when, setWhen] = useState(""); const [notes, setNotes] = useState(""); const [touched, setTouched] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState<unknown>(null);
  const batches = useApiQuery<Batch[]>(["batches", "picker"], "batches", { query: { project_id: current?.id, limit: 100 }, enabled: !!current, offline: true });
  const samples = useApiQuery<Sample[]>(["samples"], batchId ? `batches/${batchId}/samples` : null, { enabled: !!batchId });
  const built = buildValues(type, s); const errs = { ...built.errors, ...(batchId ? {} : { batch: "Choose a batch" }) };
  const server = error ? friendly(error, t).fields : {};
  const doc = sp.get("doc"), action = sp.get("action");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setTouched(true); if (Object.keys(errs).length) return;
    const body: Record<string, unknown> = { id: uuid(), batch_id: batchId, test_type: type, values: built.values };
    if (sampleId) body.sample_id = sampleId; if (built.age_days) body.age_days = built.age_days; if (lab.trim()) body.lab_name = lab.trim(); if (notes.trim()) body.notes = notes.trim();
    if (when) body.tested_at = new Date(when).toISOString(); if (action) body.investigation_action_id = action;
    setBusy(true); setError(null);
    try {
      const r = await submitOrQueue<TestRec>({ userId: user!.id, type: "test.create", data: body, label: `Test result: ${type.replaceAll("_", " ")}`, online: () => api<TestRec>("tests", { method: "POST", body }) });
      if (r.queued) { toast({ kind: "info", title: "Saved on this device", message: "The result is NOT yet confirmed or validated. It will be sent when you're online." }); router.push("/sync"); return; }
      if (doc) { try { await api(`documents/${doc}/attach`, { method: "POST", body: { test_id: r.result.id } }); } catch { toast({ kind: "warning", title: "Test saved, but the photo could not be attached", message: "You can attach it from the test page." }); } }
      toast({ kind: "success", title: "Result recorded and checked against IS limits" }); router.push(`/tests/${r.result.id}`);
    } catch (err) { setError(err); }
    setBusy(false);
  }
  const set = (k: string, v: string) => setS((x) => ({ ...x, [k]: v }));
  return (
    <RequireCap cap="test">
      <PageHeader title="Record a test result" subtitle="The verdict is computed by the IS-code rules engine, not by AI." />
      {prefill && <Alert tone="info" title="Value read from a photo">Specimen 1 is filled from the machine display. Please check it against the photo and enter the other specimens.</Alert>}
      <form onSubmit={submit} className="card stack" noValidate>
        <div className="form-grid two">
          <Field label="Batch" required error={(touched && errs.batch) || server.batch_id}><Select value={batchId} onChange={(e) => { setBatchId(e.target.value); setSampleId(""); }}><option value="">Choose…</option>{(batches.data ?? []).map((b) => <option key={b.id} value={b.id}>{b.batch_code} · {b.grade}</option>)}</Select></Field>
          <Field label="Sample" hint="Which cast sample these specimens came from"><Select value={sampleId} onChange={(e) => setSampleId(e.target.value)} disabled={!batchId}><option value="">Not linked</option>{(samples.data ?? []).map((x) => <option key={x.id} value={x.id}>{x.sample_code}</option>)}</Select></Field>
          <Field label="Test type" required><Select value={type} onChange={(e) => { setType(e.target.value); setS({ age_days: "28" }); }}>{TEST_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</Select></Field>
          <TestFields type={type} s={s} set={set} errors={touched ? { ...built.errors, ...server } : server} />
          <Field label="Laboratory / tester"><Input value={lab} onChange={(e) => setLab(e.target.value)} /></Field>
          <Field label="Tested at" hint="Leave empty for now"><Input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} /></Field>
          <Field label="Notes" className="span2"><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
        </div>
        <FormError error={error} />
        <div className="actions"><Button onClick={() => router.back()}>{t("common.cancel")}</Button><Button type="submit" variant="primary" loading={busy}>Record result</Button></div>
      </form>
    </RequireCap>
  );
}
export default function Page() { return <Suspense fallback={<SkeletonRows />}><Inner /></Suspense>; }
