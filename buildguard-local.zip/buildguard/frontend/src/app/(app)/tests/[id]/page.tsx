"use client";
import { AlertTriangle, CheckCircle2, ShieldCheck, Sparkles, XCircle } from "lucide-react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import { DocList } from "@/components/DocList";
import { useProject, useSession } from "@/components/Providers";
import { buildValues, TestFields, type TState } from "@/components/TestFields";
import { UploadBox } from "@/components/UploadBox";
import { Field, Select, Textarea, Input } from "@/components/ui/form";
import { Modal, useToast } from "@/components/ui/overlay";
import { Alert, Badge, Button, Card, ErrorState, Kv, PageHeader, SkeletonRows, StaleNote, StatusBadge } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { friendly } from "@/lib/errors";
import { fmtDateTime, TEST_LABEL } from "@/lib/format";
import { useApiMutation, useApiQuery } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { can } from "@/lib/perm";
import type { Outcome, TestRec } from "@/lib/types";
import { FormError } from "@/components/ui/ui";

const VALUE_LABEL: Record<string, string> = { specimens_mpa: "Specimen strengths (N/mm²)", slump_mm: "Slump (mm)", placing_condition: "Placing condition", temperature_c: "Temperature (°C)", cores_equiv_cube_mpa: "Core strengths, cube-equivalent (N/mm²)", velocity_km_s: "Pulse velocity (km/s)", rebound_number_avg: "Average rebound number", estimated_strength_mpa: "Estimated strength (N/mm²)" };
const OI = { VERIFIED: CheckCircle2, REVIEW_REQUIRED: AlertTriangle, FLAGGED: XCircle, PENDING: AlertTriangle } as const;
const fromValues = (type: string, v: Record<string, unknown>, age: number | null): TState => {
  const sp = (v.specimens_mpa as number[] | undefined) ?? [];
  return { age_days: String(age ?? 28), s1: String(sp[0] ?? ""), s2: String(sp[1] ?? ""), s3: String(sp[2] ?? ""), slump_mm: String(v.slump_mm ?? ""), placing_condition: String(v.placing_condition ?? ""), temperature_c: String(v.temperature_c ?? ""),
    cores: ((v.cores_equiv_cube_mpa as number[] | undefined) ?? []).join(", "), velocity_km_s: String(v.velocity_km_s ?? ""), rebound_number_avg: String(v.rebound_number_avg ?? ""), estimated_strength_mpa: String(v.estimated_strength_mpa ?? "") };
};
export default function TestDetail() {
  const { id } = useParams<{ id: string }>(); const { t, lang } = useT(); const { user } = useSession(); const { current } = useProject(); const toast = useToast();
  const q = useApiQuery<TestRec>(["test", id], `tests/${id}`, { query: { lang }, offline: true });
  const [seal, setSeal] = useState<{ seal_valid: boolean; message: string } | null>(null); const [why, setWhy] = useState<{ explanation: string; generated_by: string } | null>(null);
  const [modal, setModal] = useState<"review" | "amend" | null>(null); const [rev, setRev] = useState({ decision: "accepted", comment: "" }); const [am, setAm] = useState<TState>({}); const [reason, setReason] = useState("");
  const verify = useApiMutation(() => api<{ seal_valid: boolean; message: string }>(`tests/${id}/verify`), { onSuccess: setSeal });
  const explain = useApiMutation(() => api<{ explanation: string; generated_by: string }>(`ai/tests/${id}/explain`, { query: { lang } }), { onSuccess: setWhy });
  const review = useApiMutation(() => api(`tests/${id}/review`, { method: "POST", body: rev }), { invalidate: [["test", id], ["tests"], ["batch"], ["dashboard"]], onSuccess: () => { setModal(null); toast({ kind: "success", title: "Review recorded" }); } });
  const t2 = q.data; const built = t2 ? buildValues(t2.test_type, am) : null;
  const amend = useApiMutation(async () => api<TestRec>(`tests/${id}/amend`, { method: "POST", body: { values: built!.values, age_days: built!.age_days ?? t2?.age_days ?? undefined, reason } }), { invalidate: [["test"], ["tests"], ["batch"], ["dashboard"]], onSuccess: (r) => { setModal(null); toast({ kind: "success", title: "Amended: a new version was created", message: "The original is kept in the audit trail." }); window.location.assign(`/tests/${r.id}`); } });
  if (q.isLoading) return <SkeletonRows rows={5} />; if (q.error || !t2) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  const needsReview = t2.status !== "VERIFIED" && !t2.review;
  return (
    <div className="stack">
      <PageHeader title={TEST_LABEL[t2.test_type] ?? t2.test_type} subtitle={<span className="row"><StatusBadge status={t2.status} /><Badge>v{t2.version}{t2.is_current === false ? " · older version" : ""}</Badge>{t2.age_days ? <Badge>{t2.age_days}-day</Badge> : null}</span>}
        actions={<><Link className="btn" href={`/batches/${t2.batch_id}`}>Open batch</Link></>} />
      <StaleNote at={q.savedAt} />
      {t2.is_current === false && <Alert tone="warning">This is an older version that was later amended. Open the batch to see the current one.</Alert>}
      <div className="grid cols-2">
        <Card title="Recorded values"><Kv items={[...Object.entries(t2.values).map(([k, v]): [string, string] => [VALUE_LABEL[k] ?? k.replaceAll("_", " "), Array.isArray(v) ? v.join(", ") : String(v).replaceAll("_", " ")]), ["Laboratory", t2.lab_name], ["Tested", fmtDateTime(t2.tested_at, lang)], ["Notes", t2.notes]]} />
          {t2.review && <Alert tone={t2.review.decision === "accepted" ? "success" : "danger"} title={`Engineer review: ${t2.review.decision}`}>{t2.review.comment}</Alert>}</Card>
        <Card title="Record integrity">
          <p className="small muted">Each result is sealed with a hash of its content. Verify to confirm nothing changed since it was saved.</p>
          <div className="row"><Button loading={verify.isPending} onClick={() => verify.mutate(undefined)}><ShieldCheck size={16} aria-hidden />Verify seal</Button>
            <Button loading={explain.isPending} onClick={() => explain.mutate(undefined)}><Sparkles size={16} aria-hidden />Explain in plain words</Button></div>
          {seal && <Alert tone={seal.seal_valid ? "success" : "danger"}>{seal.seal_valid ? "✓ " : "✕ "}{seal.message}</Alert>}
          {why && <div className="card" style={{ background: "var(--bg)" }}><p style={{ margin: 0 }}>{why.explanation}</p><p className="hint" style={{ margin: ".4rem 0 0" }}>{why.generated_by === "template" ? "Written from the rule results (no AI model)." : "AI wording of the rule results. The verdict itself comes from the rules engine."}</p></div>}
          <FormError error={verify.error ?? explain.error} />
        </Card>
      </div>
      <Card title="IS-code checks" actions={<span className="hint">{t2.validation.length} rule{t2.validation.length === 1 ? "" : "s"}</span>}>
        <ul className="list">{t2.validation.map((o: Outcome) => { const I = OI[o.status]; return (
          <li key={o.rule_id}><div className="row between"><strong>{o.title}</strong><StatusBadge status={o.status} /></div>
            <div className="small muted">{o.reference}</div><div className="small">Requirement: {o.requirement} · Observed: <strong>{String(o.observed)}</strong></div><p className="small" style={{ margin: ".25rem 0 0" }}><I size={14} aria-hidden style={{ verticalAlign: "-2px" }} /> {o.explanation}</p></li>); })}</ul>
      </Card>
      <div className="row">
        {can(user, "review") && needsReview && t2.is_current !== false && <Button variant="primary" onClick={() => setModal("review")}>Record engineer review</Button>}
        {can(user, "test") && t2.is_current !== false && <Button onClick={() => { setAm(fromValues(t2.test_type, t2.values, t2.age_days)); setModal("amend"); }}>Amend result</Button>}
      </div>
      <Card title="Evidence">
        <DocList query={{ test_id: id }} empty="No photos or reports on this result yet" />
        {can(user, "test") && current && <details style={{ marginTop: ".75rem" }}><summary style={{ cursor: "pointer", minHeight: 44, display: "flex", alignItems: "center" }}>Add a photo or report</summary><UploadBox projectId={t2.project_id} batchId={t2.batch_id} sampleId={t2.sample_id ?? undefined} testId={id} kinds={["photo", "report", "lab_certificate"]} /></details>}
      </Card>
      <Modal open={modal === "review"} onClose={() => setModal(null)} title="Engineer review" footer={<><Button onClick={() => setModal(null)}>{t("common.cancel")}</Button><Button variant="primary" loading={review.isPending} disabled={rev.comment.trim().length < 3} onClick={() => review.mutate(undefined)}>Save review</Button></>}>
        <div className="stack"><Field label="Decision" required><Select value={rev.decision} onChange={(e) => setRev({ ...rev, decision: e.target.value })}><option value="accepted">Accept with justification</option><option value="rejected">Reject</option></Select></Field>
          <Field label="Justification" required hint="Minimum 3 characters. This is recorded in the audit trail."><Textarea value={rev.comment} onChange={(e) => setRev({ ...rev, comment: e.target.value })} /></Field><FormError error={review.error} /></div>
      </Modal>
      <Modal open={modal === "amend"} onClose={() => setModal(null)} title="Amend result" footer={<><Button onClick={() => setModal(null)}>{t("common.cancel")}</Button><Button variant="primary" loading={amend.isPending} disabled={reason.trim().length < 5 || !!Object.keys(built?.errors ?? {}).length} onClick={() => amend.mutate(undefined)}>Save new version</Button></>}>
        <div className="stack"><Alert tone="info">Amending never overwrites: a new version is created and the original stays in the audit trail.</Alert>
          <div className="form-grid"><TestFields type={t2.test_type} s={am} set={(k, v) => setAm((x) => ({ ...x, [k]: v }))} errors={built?.errors ?? {}} /></div>
          <Field label="Reason for amendment" required hint="At least 5 characters"><Input value={reason} onChange={(e) => setReason(e.target.value)} /></Field><FormError error={amend.error} />{amend.error ? <span className="sr-only">{friendly(amend.error, t).message}</span> : null}</div>
      </Modal>
    </div>
  );
}
