"use client";
import Link from "next/link";
import { Suspense } from "react";
import { RequireCap } from "@/components/AppShell";
import { useProject } from "@/components/Providers";
import { Alert, Badge, Card, EmptyState, ErrorState, PageHeader, SkeletonRows, TabPanel, Tabs } from "@/components/ui/ui";
import { fmtNum } from "@/lib/format";
import { useApiQuery } from "@/lib/hooks";
import type { Finding, Prediction } from "@/lib/types";
import { useUrlParams } from "@/lib/urlstate";

function Inner() {
  const { current } = useProject(); const [f, setF] = useUrlParams(["tab"] as const); const tab = f.tab || "early"; const pid = current?.id;
  const pred = useApiQuery<{ predictions: Prediction[] }>(["predict"], pid ? `predict/projects/${pid}` : null, { enabled: !!pid });
  const integ = useApiQuery<{ level: string; count: number; findings: Finding[]; disclaimer: string }>(["integrity"], pid ? `integrity/projects/${pid}` : null, { enabled: !!pid });
  return (
    <RequireCap cap="screen">
      <PageHeader title="Insights" subtitle="Indicative screening to help you look in the right place. Not a test result." />
      <Tabs label="Insight types" value={tab} onChange={(id) => setF({ tab: id })} tabs={[{ id: "early", label: "Early warning" }, { id: "integrity", label: "Result integrity" }]} />
      <TabPanel id="early" value={tab}>
        {pred.isLoading ? <SkeletonRows /> : pred.error ? <ErrorState error={pred.error} onRetry={() => pred.refetch()} /> : !pred.data?.predictions.length ? <EmptyState title="No forecasts yet" hint="A forecast needs 7-day cube results." /> : (
          <div className="grid cols-2">{pred.data.predictions.map((p) => (
            <Card key={(p.sample_code ?? "") + p.batch_id} title={<Link href={`/batches/${p.batch_id}`}>{p.batch_code}</Link>} actions={<Badge tone={p.status === "ON_TRACK" ? "success" : p.status === "AT_RISK" ? "danger" : "warning"}>{p.status === "ON_TRACK" ? "✓ On track" : p.status === "AT_RISK" ? "✕ At risk" : "⚠ Watch"}</Badge>}>
              <p className="small" style={{ marginTop: 0 }}>7-day mean {fmtNum(p.mean_7d_mpa)} N/mm² → expected 28-day <strong>{fmtNum(p.predicted_28d_mpa.estimate)}</strong> (range {fmtNum(p.predicted_28d_mpa.low)}–{fmtNum(p.predicted_28d_mpa.high)}). Grade {p.grade} needs {fmtNum(p.required_group_mean_mpa)}.</p><p className="hint">{p.note}</p></Card>))}</div>
        )}
      </TabPanel>
      <TabPanel id="integrity" value={tab}>
        {integ.isLoading ? <SkeletonRows /> : integ.error ? <ErrorState error={integ.error} onRetry={() => integ.refetch()} /> : !integ.data?.findings.length ? <EmptyState title="No unusual patterns" hint="✓ Nothing in the recorded results looks statistically odd." /> : (
          <div className="stack">{integ.data.findings.map((x) => <Card key={x.check + x.title} title={x.title} actions={<Badge tone={x.severity === "high" ? "danger" : "warning"}>{x.severity}</Badge>}><p>{x.detail}</p><ul className="list">{x.tests.map((t) => <li key={t.test_id}><Link href={`/tests/${t.test_id}`}>{t.batch_code}{t.age_days ? ` · ${t.age_days} d` : ""}</Link>{t.lab ? ` · ${t.lab}` : ""}</li>)}</ul></Card>)}<Alert tone="info">{integ.data.disclaimer}</Alert></div>
        )}
      </TabPanel>
    </RequireCap>
  );
}
export default function Page() { return <Suspense fallback={<SkeletonRows />}><Inner /></Suspense>; }
