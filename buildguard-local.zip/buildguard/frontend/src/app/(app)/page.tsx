"use client";
import { AlertTriangle, CheckCircle2, XCircle, Clock } from "lucide-react";
import Link from "next/link";
import { useProject, useSession } from "@/components/Providers";
import { Badge, Card, EmptyState, ErrorState, LinkButton, PageHeader, SkeletonCards, SkeletonRows, Stat, StaleNote, StatusBadge } from "@/components/ui/ui";
import { DataTable } from "@/components/ui/DataTable";
import { useApiQuery } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { fmtDate, fmtNum, timeAgo } from "@/lib/format";
import { can } from "@/lib/perm";
import type { Dashboard, Finding, Prediction, Status, Supplier } from "@/lib/types";

const ORDER: Status[] = ["VERIFIED", "REVIEW_REQUIRED", "FLAGGED", "PENDING"];
const ICON = { VERIFIED: CheckCircle2, REVIEW_REQUIRED: AlertTriangle, FLAGGED: XCircle, PENDING: Clock };

export default function DashboardPage() {
  const { t } = useT(); const { user } = useSession(); const { current, loading: pl } = useProject();
  const pid = current?.id;
  const d = useApiQuery<Dashboard>(["dashboard"], "dashboard/summary", { query: { project_id: pid }, enabled: !!pid, offline: true, refetchInterval: 60_000 });
  const pred = useApiQuery<{ predictions: Prediction[] }>(["predict"], pid ? `predict/projects/${pid}` : null, { enabled: !!pid });
  const integ = useApiQuery<{ level: string; count: number; findings: Finding[] }>(["integrity"], pid ? `integrity/projects/${pid}` : null, { enabled: !!pid && can(user, "screen") });

  if (pl || d.isLoading) return <><PageHeader title={t("dash.title")} /><SkeletonCards /><div style={{ height: 16 }} /><SkeletonRows rows={4} /></>;
  if (!current) return <EmptyState title="No projects yet" hint="Create a project to start registering concrete batches." action={can(user, "write") ? <LinkButton href="/projects" variant="primary">Create a project</LinkButton> : undefined} />;
  if (d.error) return <ErrorState error={d.error} onRetry={() => d.refetch()} />;
  const s = d.data!; const total = Object.values(s.batch_status).reduce((a, b) => a + (b ?? 0), 0);
  const atRisk = (pred.data?.predictions ?? []).filter((p) => p.status !== "ON_TRACK");
  return (
    <div className="stack">
      <PageHeader title={t("dash.title")} subtitle={current.name} actions={can(user, "write") ? <LinkButton href="/batches/new" variant="primary">{t("batches.new")}</LinkButton> : undefined} />
      <StaleNote at={d.savedAt} />
      <div className="grid cols-4">
        <Stat label="Batches" value={s.totals.batches} href="/batches" /><Stat label="Tests recorded" value={s.totals.tests} href="/tests" />
        <Stat label="Open alerts" value={s.totals.open_alerts} tone={s.totals.open_alerts ? "danger" : undefined} href="/alerts" /><Stat label="Open investigations" value={s.totals.open_investigations} href="/investigations" />
      </div>
      <Card title="Batch status">
        {total === 0 ? <EmptyState title={t("dash.empty")} hint="Register a batch to get its QR passport and start tracking tests." action={can(user, "write") ? <LinkButton href="/batches/new" variant="primary">{t("batches.new")}</LinkButton> : undefined} /> : (
          <div className="stack-sm">
            <div className="seg" role="img" aria-label={ORDER.map((k) => `${t(`status.${k}`)}: ${s.batch_status[k] ?? 0}`).join(", ")}>{ORDER.map((k) => <span key={k} className={`s-${k}`} style={{ width: `${((s.batch_status[k] ?? 0) / total) * 100}%` }} />)}</div>
            <div className="row">{ORDER.map((k) => { const I = ICON[k]; return <Link key={k} href={`/batches?status=${k}`} className="row small" style={{ gap: ".3rem", textDecoration: "none", color: "var(--text)" }}><I size={16} aria-hidden />{t(`status.${k}`)} <strong>{s.batch_status[k] ?? 0}</strong></Link>; })}</div>
          </div>
        )}
      </Card>
      <div className="grid cols-2">
        <Card title="Needs attention">
          {s.overdue_tests.length + s.sampling_shortfall.length + s.tests_missing_evidence.length === 0 ? <p className="muted">✓ Nothing overdue. Sampling and evidence are up to date.</p> : (
            <ul className="list">
              {s.overdue_tests.slice(0, 4).map((o) => <li key={o.sample_code + o.age_days}><Badge tone="danger" icon={<XCircle size={14} aria-hidden />}>Overdue</Badge> {o.age_days}-day test for <span className="mono">{o.sample_code}</span> was due {fmtDate(o.due_date)}</li>)}
              {s.sampling_shortfall.slice(0, 4).map((o) => <li key={o.batch_code}><Badge tone="warning" icon={<AlertTriangle size={14} aria-hidden />}>Sampling</Badge> <Link href={`/batches?q=${o.batch_code}`}>{o.batch_code}</Link>: {o.taken} of {o.required} samples taken</li>)}
              {s.tests_missing_evidence.slice(0, 3).map((o) => <li key={o.test_id}><Badge tone="warning" icon={<AlertTriangle size={14} aria-hidden />}>Evidence</Badge> <Link href={`/tests/${o.test_id}`}>A {o.test_type.replaceAll("_", " ")} result</Link> has no photo or report attached</li>)}
            </ul>
          )}
        </Card>
        <Card title="Recent alerts" actions={<Link href="/alerts" className="small">View all</Link>}>
          {s.recent_alerts.length === 0 ? <p className="muted">✓ No alerts.</p> : <ul className="list">{s.recent_alerts.slice(0, 5).map((a) => <li key={a.id}><Badge tone={a.severity === "high" ? "danger" : "warning"} icon={a.severity === "high" ? <XCircle size={14} aria-hidden /> : <AlertTriangle size={14} aria-hidden />}>{a.severity}</Badge> {a.message} <span className="hint">{timeAgo(a.created_at)}</span></li>)}</ul>}
        </Card>
      </div>
      <div className="grid cols-3">
        <Card title="Early warning (7 → 28 day)" actions={<Link href="/insights" className="small">Details</Link>}>
          {atRisk.length === 0 ? <p className="muted">✓ No samples are trending below target.</p> : <ul className="list">{atRisk.slice(0, 3).map((p) => <li key={p.sample_code ?? p.batch_id}><Badge tone={p.status === "AT_RISK" ? "danger" : "warning"} icon={<AlertTriangle size={14} aria-hidden />}>{p.status === "AT_RISK" ? "At risk" : "Watch"}</Badge> <Link href={`/batches/${p.batch_id}`}>{p.batch_code}</Link>: ~{fmtNum(p.predicted_28d_mpa.estimate)} N/mm² expected (need {fmtNum(p.required_group_mean_mpa)})</li>)}</ul>}
          <p className="hint">Estimates only. The 28-day test decides.</p>
        </Card>
        <Card title="Durability risk" actions={<Link href="/risk" className="small">Risk map</Link>}>
          <div className="row">{Object.entries(s.durability_risk.counts).map(([k, v]) => <Badge key={k} tone={k === "High" ? "danger" : k === "Moderate" ? "warning" : "success"}>{k}: {v}</Badge>)}{Object.keys(s.durability_risk.counts).length === 0 && <span className="muted">No assessments yet.</span>}</div>
        </Card>
        {can(user, "screen") && (
          <Card title="Result integrity" actions={<Link href="/insights?tab=integrity" className="small">Details</Link>}>
            {integ.isLoading ? <SkeletonRows rows={1} /> : <p style={{ margin: 0 }}>{(integ.data?.count ?? 0) === 0 ? "✓ No unusual patterns found." : <><Badge tone={integ.data?.level === "high" ? "danger" : "warning"} icon={<AlertTriangle size={14} aria-hidden />}>{integ.data?.count} to review</Badge></>}</p>}
            <p className="hint">Indicative screening, not proof.</p>
          </Card>
        )}
      </div>
      <Card title="Supplier scorecards">
        {s.supplier_scorecards.length === 0 ? <p className="muted">Scorecards appear once suppliers have tested batches.</p> : (
          <DataTable<Supplier> caption="Supplier scorecards" rowKey={(r) => r.supplier} rows={s.supplier_scorecards} columns={[
            { key: "s", header: "Supplier", cell: (r) => r.supplier }, { key: "b", header: "Batches", cell: (r) => r.batches }, { key: "f", header: "Flagged", cell: (r) => `${r.flagged} (${fmtNum(r.flag_rate * 100, 0)}%)` },
            { key: "m", header: "Avg. 28-day margin", cell: (r) => (r.avg_28d_margin_over_fck_mpa === null ? "—" : `${fmtNum(r.avg_28d_margin_over_fck_mpa)} N/mm²`) }, { key: "r", header: "Reliability", cell: (r) => (r.reliability_score === null ? "—" : `${fmtNum(r.reliability_score, 0)}/100`) } ]} />
        )}
        <p className="hint">Indicative, based only on recorded batches.</p>
      </Card>
      <p className="hint"><StatusBadge status="VERIFIED" /> verdicts come from the IS-code rules engine, not from AI.</p>
    </div>
  );
}
