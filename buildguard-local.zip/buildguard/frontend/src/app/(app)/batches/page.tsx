"use client";
import { Search, X } from "lucide-react";
import { Suspense, useEffect, useState } from "react";
import { useProject, useSession } from "@/components/Providers";
import { DataTable } from "@/components/ui/DataTable";
import { Field, Input, Select } from "@/components/ui/form";
import { Button, EmptyState, ErrorState, LinkButton, PageHeader, SkeletonRows, StaleNote, StatusBadge } from "@/components/ui/ui";
import { fmtDate, fmtNum } from "@/lib/format";
import { useApiQuery, useDebounced, useInfiniteApi } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { can } from "@/lib/perm";
import type { Batch } from "@/lib/types";
import { useUrlParams } from "@/lib/urlstate";

const CODE = /^CON-M\d{2}-\d{3,}$/i;
function BatchesInner() {
  const { t, lang } = useT(); const { user } = useSession(); const { current } = useProject();
  const [f, setF] = useUrlParams(["q", "status", "grade"] as const);
  const [text, setText] = useState(f.q);
  useEffect(() => setText(f.q), [f.q]);
  const debounced = useDebounced(text, 400);                                   // one request after the user pauses, not one per keystroke
  useEffect(() => { if (debounced !== f.q) setF({ q: debounced }); }, [debounced]); // eslint-disable-line react-hooks/exhaustive-deps
  const isCode = CODE.test(f.q.trim());
  const byCode = useApiQuery<Batch>(["batch-code"], isCode ? `batches/by-code/${f.q.trim().toUpperCase()}` : null, { enabled: isCode });
  const list = useInfiniteApi<Batch>(["batches"], "batches", { project_id: current?.id, status: f.status, grade: f.grade, supplier: isCode ? undefined : f.q.trim() }, 20, { offline: true, enabled: !!current && !isCode });
  const rows = isCode ? (byCode.data ? [byCode.data] : []) : list.items;
  const loading = isCode ? byCode.isLoading : list.isLoading; const error = isCode ? (byCode.error?.kind === "notfound" ? null : byCode.error) : list.error;
  const filtered = !!(f.q || f.status || f.grade);
  return (
    <div className="stack">
      <PageHeader title={t("batches.title")} subtitle={current?.name} actions={can(user, "write") ? <LinkButton href="/batches/new" variant="primary">{t("batches.new")}</LinkButton> : undefined} />
      <form className="card filters" role="search" onSubmit={(e) => e.preventDefault()}>
        <div className="span2 row" style={{ alignItems: "flex-end", flexWrap: "nowrap" }}>
          <Field plain label={t("batches.search")} className="grow"><Input type="search" value={text} onChange={(e) => setText(e.target.value)} placeholder="e.g. UltraMix or CON-M25-001" autoComplete="off" enterKeyHint="search" /></Field>
          {text && <Button icon onClick={() => { setText(""); setF({ q: "" }); }} aria-label={t("common.clear")}><X size={18} aria-hidden /></Button>}
        </div>
        <Field plain label={t("common.status")}><Select value={f.status} onChange={(e) => setF({ status: e.target.value })}><option value="">{t("common.all")}</option>{["VERIFIED", "REVIEW_REQUIRED", "FLAGGED", "PENDING"].map((s) => <option key={s} value={s}>{t(`status.${s}`)}</option>)}</Select></Field>
        <Field plain label="Grade"><Select value={f.grade} onChange={(e) => setF({ grade: e.target.value })}><option value="">{t("common.all")}</option>{["M15", "M20", "M25", "M30", "M35", "M40"].map((g) => <option key={g}>{g}</option>)}</Select></Field>
      </form>
      <StaleNote at={list.savedAt} />
      <div aria-live="polite" className="small muted">{!loading && rows.length > 0 ? `${rows.length}${!isCode && list.hasNextPage ? "+" : ""} batch${rows.length === 1 ? "" : "es"}` : ""}</div>
      {loading ? <SkeletonRows rows={6} /> : error ? <ErrorState error={error} onRetry={() => (isCode ? byCode.refetch() : list.refetch())} /> : rows.length === 0 ? (
        filtered ? <EmptyState icon={<Search size={36} aria-hidden />} title="No batches match" hint="Try a different search or clear the filters." action={<Button onClick={() => { setText(""); setF({ q: "", status: "", grade: "" }); }}>{t("common.clear")}</Button>} />
          : <EmptyState title={t("dash.empty")} hint="Register your first batch to get a QR passport and start tracking tests." action={can(user, "write") ? <LinkButton href="/batches/new" variant="primary">{t("batches.new")}</LinkButton> : undefined} />
      ) : (
        <>
          <DataTable<Batch> caption="Batches" rowKey={(b) => b.id} href={(b) => `/batches/${b.id}`} rows={rows} columns={[
            { key: "c", header: "Batch", cell: (b) => <strong>{b.batch_code}</strong> }, { key: "g", header: "Grade", cell: (b) => b.grade }, { key: "s", header: "Supplier", cell: (b) => b.supplier ?? "—" },
            { key: "q", header: "Quantity", cell: (b) => `${fmtNum(b.quantity_m3)} m³` }, { key: "d", header: "Delivered", cell: (b) => fmtDate(b.delivery_date, lang) }, { key: "st", header: t("common.status"), cell: (b) => <StatusBadge status={b.status} /> } ]} />
          {!isCode && list.hasNextPage && <div className="row" style={{ justifyContent: "center" }}><Button onClick={() => list.fetchNextPage()} loading={list.isFetchingNextPage}>{t("common.loadMore")}</Button></div>}
        </>
      )}
    </div>
  );
}
export default function Page() { return <Suspense fallback={<SkeletonRows />}><BatchesInner /></Suspense>; }
