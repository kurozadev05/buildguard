"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { RequireCap } from "@/components/AppShell";
import { useProject, useSession } from "@/components/Providers";
import { Field, Input, Select, Textarea } from "@/components/ui/form";
import { useToast } from "@/components/ui/overlay";
import { Alert, Button, FormError, PageHeader } from "@/components/ui/ui";
import { ApiError, api } from "@/lib/api";
import { friendly } from "@/lib/errors";
import { uuid } from "@/lib/format";
import { useT } from "@/lib/i18n";
import { submitOrQueue } from "@/lib/offline/queue";
import type { Batch } from "@/lib/types";

const num = (s: string) => (s.trim() === "" ? undefined : Number(s));
export default function NewBatch() {
  const { t } = useT(); const router = useRouter(); const toast = useToast(); const { user } = useSession(); const { projects, current, loading: projectsLoading } = useProject();
  const [f, setF] = useState({ project_id: "", grade: "M25", construction_type: "rcc", exposure: "moderate", supplier: "", supplier_ref: "", delivery_date: "", quantity_m3: "", cement_type: "opc", cement_content_kg_m3: "", wc_ratio: "", admixture: "", mix_notes: "" });
  const [touched, setTouched] = useState(false); const [busy, setBusy] = useState(false); const [error, setError] = useState<unknown>(null); const [queued, setQueued] = useState<string | null>(null);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const pid = f.project_id || current?.id || "";
  const qty = num(f.quantity_m3), wc = num(f.wc_ratio), cem = num(f.cement_content_kg_m3);
  const errs: Record<string, string> = {};
  if (!qty || qty <= 0 || qty > 10000) errs.quantity_m3 = "Enter a quantity between 0 and 10,000 m³";
  if (wc !== undefined && (wc <= 0 || wc > 1)) errs.wc_ratio = "Water-cement ratio is between 0 and 1";
  if (cem !== undefined && (cem <= 0 || cem > 800)) errs.cement_content_kg_m3 = "Enter a value up to 800 kg/m³";
  if (!pid) errs.project_id = "Choose a project";
  const server = error ? friendly(error, t).fields : {};
  const show = (k: string) => (touched ? errs[k] : undefined) ?? server[k];
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setTouched(true);
    if (Object.keys(errs).length) { toast({ kind: "warning", title: "Please fix the highlighted fields", message: errs.project_id ?? undefined }); return; }   // never fail silently
    const id = uuid(); const body: Record<string, unknown> = { id, project_id: pid, grade: f.grade, construction_type: f.construction_type, exposure: f.exposure, quantity_m3: qty, cement_type: f.cement_type };
    if (f.supplier.trim()) body.supplier = f.supplier.trim(); if (f.supplier_ref.trim()) body.supplier_ref = f.supplier_ref.trim(); if (f.delivery_date) body.delivery_date = f.delivery_date;
    if (cem !== undefined) body.cement_content_kg_m3 = cem; if (wc !== undefined) body.wc_ratio = wc; if (f.admixture.trim()) body.admixture = f.admixture.trim(); if (f.mix_notes.trim()) body.mix_notes = f.mix_notes.trim();
    setBusy(true); setError(null);
    try {
      const r = await submitOrQueue<Batch>({ userId: user!.id, type: "batch.create", data: body, label: `New batch ${f.grade} · ${qty} m³`, online: () => api<Batch>("batches", { method: "POST", body }) });
      if (r.queued) { setQueued(r.op.label); toast({ kind: "info", title: "Saved on this device", message: "Not yet confirmed by the server. It will be sent automatically when you're online." }); }
      else { toast({ kind: "success", title: `Batch ${r.result.batch_code} registered` }); router.push(`/batches/${r.result.id}`); }
    } catch (err) { setError(err); if (err instanceof ApiError && err.kind === "timeout") toast({ kind: "warning", title: "No confirmation received", message: "Check the batch list before trying again to avoid a duplicate." }); }
    setBusy(false);
  }
  return (
    <RequireCap cap="write">
      <PageHeader title={t("batches.new")} subtitle="Register a concrete delivery. It is checked against IS 456 limits immediately." />
      {queued && <Alert tone="warning" title="Pending sync">“{queued}” is saved on this device and will be sent when you are online. <Link href="/sync">View pending changes</Link>.</Alert>}
      <form onSubmit={submit} className="card stack" noValidate>
        <div className="form-grid two">
          <Field label={t("common.project")} required error={show("project_id")}><Select value={pid} onChange={set("project_id")}>{projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</Select></Field>
          <Field label="Grade" required error={show("grade")}><Select value={f.grade} onChange={set("grade")}>{["M10", "M15", "M20", "M25", "M30", "M35", "M40", "M45", "M50"].map((g) => <option key={g}>{g}</option>)}</Select></Field>
          <Field label="Construction type"><Select value={f.construction_type} onChange={set("construction_type")}><option value="rcc">RCC (reinforced)</option><option value="pcc">PCC (plain)</option></Select></Field>
          <Field label="Exposure condition" hint="IS 456 Table 3"><Select value={f.exposure} onChange={set("exposure")}>{["mild", "moderate", "severe", "very_severe", "extreme"].map((x) => <option key={x} value={x}>{x.replace("_", " ")}</option>)}</Select></Field>
          <Field label="Quantity (m³)" required error={show("quantity_m3")}><Input type="number" inputMode="decimal" min="0" step="any" value={f.quantity_m3} onChange={set("quantity_m3")} /></Field>
          <Field label="Delivery date"><Input type="date" value={f.delivery_date} onChange={set("delivery_date")} /></Field>
          <Field label="Supplier" error={show("supplier")}><Input value={f.supplier} onChange={set("supplier")} autoComplete="organization" /></Field>
          <Field label="Delivery challan / reference"><Input value={f.supplier_ref} onChange={set("supplier_ref")} /></Field>
          <Field label="Cement type"><Select value={f.cement_type} onChange={set("cement_type")}><option value="opc">OPC</option><option value="ppc">PPC</option><option value="psc">PSC</option><option value="other">Other</option></Select></Field>
          <Field label="Cement content (kg/m³)" hint="From the mix design or challan" error={show("cement_content_kg_m3")}><Input type="number" inputMode="decimal" step="any" value={f.cement_content_kg_m3} onChange={set("cement_content_kg_m3")} /></Field>
          <Field label="Water-cement ratio" hint="Between 0 and 1" error={show("wc_ratio")}><Input type="number" inputMode="decimal" step="0.01" value={f.wc_ratio} onChange={set("wc_ratio")} /></Field>
          <Field label="Admixture"><Input value={f.admixture} onChange={set("admixture")} /></Field>
          <Field label="Notes" className="span2"><Textarea value={f.mix_notes} onChange={set("mix_notes")} /></Field>
        </div>
        <FormError error={error} />
        <div className="actions"><Button onClick={() => router.back()}>{t("common.cancel")}</Button><Button type="submit" variant="primary" loading={busy} disabled={projectsLoading} title={projectsLoading ? "Loading your projects…" : undefined}>{t("batches.new")}</Button></div>
      </form>
    </RequireCap>
  );
}
