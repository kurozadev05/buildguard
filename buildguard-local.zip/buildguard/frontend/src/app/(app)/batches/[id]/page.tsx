"use client";
import { QrCode } from "lucide-react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { DocList } from "@/components/DocList";
import { useSession } from "@/components/Providers";
import { UploadBox } from "@/components/UploadBox";
import { DataTable } from "@/components/ui/DataTable";
import { Field, Input, Select, Textarea } from "@/components/ui/form";
import { Modal, useToast } from "@/components/ui/overlay";
import { Alert, Badge, Button, Card, EmptyState, ErrorState, FormError, Kv, LinkButton, PageHeader, Progress, SkeletonRows, StaleNote, StatusBadge, TabPanel, Tabs } from "@/components/ui/ui";
import { api } from "@/lib/api";
import { fmtDate, fmtNum, TEST_LABEL, uuid } from "@/lib/format";
import { useApiMutation, useApiQuery } from "@/lib/hooks";
import { useT } from "@/lib/i18n";
import { submitOrQueue } from "@/lib/offline/queue";
import { can } from "@/lib/perm";
import type { Batch, Finding, Prediction, Sample, TestRec, Tree } from "@/lib/types";

interface Loc { element_id?: string; path?: string; element?: string; volume_m3?: number | null; poured_at?: string | null }
interface Impact { affected_locations: Loc[]; affected_volume_m3: number; investigations: { id: string; status: string; reason: string }[] }
const flatten = (t?: Tree) => (t?.buildings ?? []).flatMap((b) => b.floors.flatMap((f) => f.elements.map((e) => ({ id: e.id, label: `${b.name} › ${f.name} › ${e.name}` }))));

export default function BatchDetail() {
  const { id } = useParams<{ id: string }>(); const { t, lang } = useT(); const { user } = useSession(); const router = useRouter(); const toast = useToast();
  const [tab, setTab] = useState("overview"); const [modal, setModal] = useState<"sample" | "usage" | "inv" | null>(null);
  const b = useApiQuery<Batch>(["batch", id], `batches/${id}`, { query: { lang }, offline: true });
  const tests = useApiQuery<TestRec[]>(["tests", "of-batch"], `tests`, { query: { batch_id: id, limit: 50, lang }, enabled: tab === "tests" || tab === "overview", offline: true });
  const samples = useApiQuery<Sample[]>(["samples", id], `batches/${id}/samples`, { offline: false });
  const impact = useApiQuery<Impact>(["impact", id], `batches/${id}/impact`, { enabled: tab === "usage" });
  const pred = useApiQuery<{ predictions: Prediction[] }>(["predict", id], `predict/batches/${id}`, { enabled: tab === "insights" });
  const integ = useApiQuery<{ level: string; findings: Finding[]; disclaimer: string }>(["integrity", id], `integrity/batches/${id}`, { enabled: tab === "insights" && can(user, "screen") });
  const tree = useApiQuery<Tree>(["tree", b.data?.project_id], b.data ? `projects/${b.data.project_id}/tree` : null, { enabled: modal === "usage", offline: true });
  const elements = useMemo(() => flatten(tree.data), [tree.data]);

  const [sm, setSm] = useState({ cast_date: new Date().toISOString().slice(0, 10), cubes_cast: "6", curing_method: "", notes: "" });
  const [us, setUs] = useState({ element_id: "", volume_m3: "", notes: "" }); const [reason, setReason] = useState("");
  const queuedToast = () => toast({ kind: "info", title: "Saved on this device", message: "Not yet confirmed by the server. It will be sent automatically." });
  const addSample = useApiMutation(async () => {
    const body = { id: uuid(), batch_id: id, cast_date: sm.cast_date, cubes_cast: Number(sm.cubes_cast), ...(sm.curing_method ? { curing_method: sm.curing_method } : {}), ...(sm.notes ? { notes: sm.notes } : {}) };
    return submitOrQueue({ userId: user!.id, type: "sample.create", data: body, label: `Sample for ${b.data?.batch_code}`, online: () => api<Sample>("samples", { method: "POST", body }) });
  }, { invalidate: [["samples"], ["batch"], ["dashboard"]], onSuccess: (r) => { setModal(null); if (r.queued) queuedToast(); else toast({ kind: "success", title: `Sample ${r.result.sample_code} added`, message: "Print its QR label from the Samples tab." }); } });
  const addUsage = useApiMutation(async () => {
    const body = { id: uuid(), batch_id: id, element_id: us.element_id, ...(us.volume_m3 ? { volume_m3: Number(us.volume_m3) } : {}), ...(us.notes ? { notes: us.notes } : {}) };
    return submitOrQueue({ userId: user!.id, type: "usage.create", data: body, label: `Pour record for ${b.data?.batch_code}`, online: () => api("usage", { method: "POST", body }) });
  }, { invalidate: [["impact"], ["risk"], ["dashboard"]], onSuccess: (r) => { setModal(null); if (r.queued) queuedToast(); else toast({ kind: "success", title: "Location recorded" }); } });
  const openInv = useApiMutation(() => api<{ id: string }>("investigations", { method: "POST", body: { batch_id: id, reason } }), { invalidate: [["investigations"], ["dashboard"]], onSuccess: (r) => { setModal(null); router.push(`/investigations/${r.id}`); } });

  if (b.isLoading) return <SkeletonRows rows={6} />; if (b.error || !b.data) return <ErrorState error={b.error} onRetry={() => b.refetch()} />;
  const x = b.data; const nSamples = samples.data?.length ?? x.samples?.length ?? 0;
  const publicUrl = typeof window !== "undefined" ? `${window.location.origin}/p/${x.public_token}` : "";
  return (
    <div className="stack">
      <PageHeader title={x.batch_code} subtitle={<span className="row"><StatusBadge status={x.status} /><Badge>{x.grade}</Badge><span>{x.supplier ?? "Supplier not recorded"}</span></span>}
        actions={<>{can(user, "test") && <LinkButton href={`/tests/new?batch=${id}`} variant="primary">Record test</LinkButton>}{can(user, "review") && x.status !== "VERIFIED" && <Button onClick={() => setModal("inv")}>Open investigation</Button>}</>} />
      <StaleNote at={b.savedAt} />
      <Tabs label="Batch sections" value={tab} onChange={setTab} tabs={[{ id: "overview", label: "Overview" }, { id: "tests", label: "Tests" }, { id: "samples", label: "Samples" }, { id: "usage", label: "Where used" }, { id: "evidence", label: "Evidence" }, { id: "insights", label: "Insights" }]} />

      <TabPanel id="overview" value={tab}>
        <div className="grid cols-2">
          <Card title="Batch details"><Kv items={[["Quantity", `${fmtNum(x.quantity_m3)} m³`], ["Delivered", fmtDate(x.delivery_date, lang)], ["Delivery ref.", x.supplier_ref], ["Construction", x.construction_type.toUpperCase()], ["Exposure", x.exposure.replace("_", " ")], ["Cement", `${x.cement_type.toUpperCase()}${x.cement_content_kg_m3 ? ` · ${x.cement_content_kg_m3} kg/m³` : ""}`], ["Water-cement ratio", x.wc_ratio], ["Admixture", x.admixture], ["Characteristic strength", `${x.fck} N/mm²`]]} /></Card>
          <Card title="QR passport" actions={<a className="btn sm" href={`/bff/batches/${id}/qr.png`} download={`${x.batch_code}.png`}>Download</a>}>
            <div className="row"><div style={{ background: "#fff", padding: 8, border: "1px solid var(--border)", borderRadius: 6 }}>{/* QR is an authenticated same-origin PNG; next/image would re-fetch it without the session cookie */}
{/* eslint-disable-next-line @next/next/no-img-element */}
<img src={`/bff/batches/${id}/qr.png`} alt={`QR code for batch ${x.batch_code}`} width={140} height={140} /></div>
              <div className="grow small"><QrCode size={16} aria-hidden /> Anyone who scans this sees a read-only summary. No login and no private data.<div className="mono" style={{ overflowWrap: "anywhere", marginTop: 6 }}>{publicUrl}</div><Button size="sm" onClick={() => { void navigator.clipboard?.writeText(publicUrl); toast({ kind: "success", title: "Link copied" }); }} style={{ marginTop: 6 }}>{t("common.copy")} link</Button></div></div>
          </Card>
        </div>
        <Card title="Registration check (IS 456)"><ul className="list">{x.registration_check.outcomes.map((o) => <li key={o.rule_id}><div className="row between"><strong>{o.title}</strong><StatusBadge status={o.status} /></div><div className="small muted">{o.reference}</div><div className="small">{o.explanation}</div></li>)}</ul></Card>
        <Card title="Sampling progress"><p className="small" style={{ marginTop: 0 }}>{nSamples} of {x.required_samples} required samples taken for {fmtNum(x.quantity_m3)} m³.</p><Progress value={nSamples} max={x.required_samples} label="Samples taken" /></Card>
      </TabPanel>

      <TabPanel id="tests" value={tab}>
        {tests.isLoading ? <SkeletonRows rows={3} /> : tests.error ? <ErrorState error={tests.error} onRetry={() => tests.refetch()} /> : !tests.data?.length ? <EmptyState title="No tests recorded yet" hint="Record a slump, temperature or cube result to start validation." action={can(user, "test") ? <LinkButton href={`/tests/new?batch=${id}`} variant="primary">Record test</LinkButton> : undefined} /> :
          <DataTable<TestRec> caption="Tests for this batch" rowKey={(r) => r.id} href={(r) => `/tests/${r.id}`} rows={tests.data} columns={[{ key: "t", header: "Test", cell: (r) => <strong>{TEST_LABEL[r.test_type] ?? r.test_type}</strong> }, { key: "a", header: "Age", cell: (r) => (r.age_days ? `${r.age_days} d` : "—") }, { key: "s", header: t("common.status"), cell: (r) => <StatusBadge status={r.status} /> }, { key: "v", header: "Version", cell: (r) => `v${r.version}` }, { key: "d", header: "Tested", cell: (r) => fmtDate(r.tested_at, lang) }]} />}
      </TabPanel>

      <TabPanel id="samples" value={tab}>
        <Card title="Samples" actions={can(user, "write") ? <Button size="sm" variant="primary" onClick={() => setModal("sample")}>Add sample</Button> : undefined}>
          {!samples.data?.length ? <EmptyState title="No samples yet" hint={`This batch needs ${x.required_samples} sample(s). Cast cubes at the pour and add them here.`} /> :
            <ul className="list">{samples.data.map((s) => <li key={s.id} className="row between"><div><strong className="mono">{s.sample_code}</strong><div className="small muted">Cast {fmtDate(s.cast_date, lang)} · {s.cubes_cast} cubes{s.curing_method ? ` · ${s.curing_method}` : ""}</div></div><div className="row"><a className="btn sm" href={`/bff/samples/${s.id}/qr.png`} download={`${s.sample_code}.png`}>QR label</a><LinkButton size="sm" href={`/tests/new?batch=${id}&sample=${s.id}`}>Record test</LinkButton></div></li>)}</ul>}
        </Card>
      </TabPanel>

      <TabPanel id="usage" value={tab}>
        <Card title="Where this batch was used" actions={can(user, "write") ? <Button size="sm" variant="primary" onClick={() => setModal("usage")}>Record location</Button> : undefined}>
          {impact.isLoading ? <SkeletonRows rows={2} /> : impact.error ? <ErrorState error={impact.error} onRetry={() => impact.refetch()} compact /> : !impact.data?.affected_locations.length ? <EmptyState title="No locations recorded" hint="Record which slab, beam or column this concrete went into so any problem can be traced." /> : (
            <><p className="small">Total recorded: <strong>{fmtNum(impact.data.affected_volume_m3)} m³</strong></p>
              <ul className="list">{impact.data.affected_locations.map((l, i) => <li key={l.element_id ?? i}>{l.path ?? l.element ?? l.element_id}{l.volume_m3 ? ` · ${fmtNum(l.volume_m3)} m³` : ""}{l.poured_at ? ` · ${fmtDate(l.poured_at, lang)}` : ""}</li>)}</ul>
              {impact.data.investigations.length > 0 && <p className="small">Investigations: {impact.data.investigations.map((v) => <Link key={v.id} href={`/investigations/${v.id}`}>{v.status}</Link>).reduce<React.ReactNode[]>((a, c, i) => (i ? [...a, ", ", c] : [c]), [])}</p>}</>
          )}
        </Card>
      </TabPanel>

      <TabPanel id="evidence" value={tab}>
        <div className="stack"><Card title="Files"><DocList query={{ batch_id: id }} /></Card>
          {can(user, "test") && <Card title="Add a photo or report"><UploadBox projectId={x.project_id} batchId={id} kinds={["photo", "delivery_challan", "report"]} /></Card>}</div>
      </TabPanel>

      <TabPanel id="insights" value={tab}>
        <div className="grid cols-2">
          <Card title="Early warning (7 → 28 day)">{pred.isLoading ? <SkeletonRows rows={1} /> : pred.error ? <ErrorState error={pred.error} compact onRetry={() => pred.refetch()} /> : !pred.data?.predictions.length ? <p className="muted">Needs 7-day cube results for this batch.</p> : pred.data.predictions.map((p) => <div key={p.sample_code ?? p.batch_id} className="stack-sm"><Badge tone={p.status === "ON_TRACK" ? "success" : p.status === "AT_RISK" ? "danger" : "warning"}>{p.status === "ON_TRACK" ? "✓ On track" : p.status === "AT_RISK" ? "✕ At risk" : "⚠ Watch"}</Badge><div className="small">Expected 28-day: <strong>{fmtNum(p.predicted_28d_mpa.estimate)}</strong> N/mm² (range {fmtNum(p.predicted_28d_mpa.low)}–{fmtNum(p.predicted_28d_mpa.high)}); need {fmtNum(p.required_group_mean_mpa)}.</div><div className="hint">{p.note}</div></div>)}</Card>
          {can(user, "screen") && <Card title="Result integrity">{integ.isLoading ? <SkeletonRows rows={1} /> : integ.error ? <ErrorState error={integ.error} compact onRetry={() => integ.refetch()} /> : !integ.data?.findings.length ? <p className="muted">✓ No unusual patterns found.</p> : <ul className="list">{integ.data.findings.map((f) => <li key={f.check}><Badge tone={f.severity === "high" ? "danger" : "warning"}>{f.severity}</Badge> <strong>{f.title}</strong><div className="small">{f.detail}</div></li>)}</ul>}<p className="hint">{integ.data?.disclaimer ?? "Indicative screening only."}</p></Card>}
        </div>
      </TabPanel>

      <Modal open={modal === "sample"} onClose={() => setModal(null)} title="Add sample" footer={<><Button onClick={() => setModal(null)}>{t("common.cancel")}</Button><Button variant="primary" loading={addSample.isPending} disabled={!sm.cast_date || Number(sm.cubes_cast) < 3} onClick={() => addSample.mutate(undefined)}>Add sample</Button></>}>
        <div className="stack"><Field label="Cast date" required><Input type="date" value={sm.cast_date} onChange={(e) => setSm({ ...sm, cast_date: e.target.value })} /></Field><Field label="Cubes cast" required hint="3 to 30"><Input type="number" min="3" max="30" value={sm.cubes_cast} onChange={(e) => setSm({ ...sm, cubes_cast: e.target.value })} /></Field>
          <Field label="Curing method"><Input value={sm.curing_method} onChange={(e) => setSm({ ...sm, curing_method: e.target.value })} /></Field><Field label="Notes"><Textarea value={sm.notes} onChange={(e) => setSm({ ...sm, notes: e.target.value })} /></Field><FormError error={addSample.error} /></div>
      </Modal>
      <Modal open={modal === "usage"} onClose={() => setModal(null)} title="Record where this batch was poured" footer={<><Button onClick={() => setModal(null)}>{t("common.cancel")}</Button><Button variant="primary" loading={addUsage.isPending} disabled={!us.element_id} onClick={() => addUsage.mutate(undefined)}>Save</Button></>}>
        <div className="stack">{tree.isLoading ? <SkeletonRows rows={1} /> : elements.length === 0 ? <Alert tone="warning">No structural elements exist yet. Add buildings, floors and elements on the <Link href={`/projects/${x.project_id}`}>project page</Link> first.</Alert> :
          <Field label="Element" required><Select value={us.element_id} onChange={(e) => setUs({ ...us, element_id: e.target.value })}><option value="">Choose…</option>{elements.map((e) => <option key={e.id} value={e.id}>{e.label}</option>)}</Select></Field>}
          <Field label="Volume poured (m³)"><Input type="number" inputMode="decimal" step="any" min="0" value={us.volume_m3} onChange={(e) => setUs({ ...us, volume_m3: e.target.value })} /></Field><Field label="Notes"><Textarea value={us.notes} onChange={(e) => setUs({ ...us, notes: e.target.value })} /></Field><FormError error={addUsage.error} /></div>
      </Modal>
      <Modal open={modal === "inv"} onClose={() => setModal(null)} title="Open an investigation" footer={<><Button onClick={() => setModal(null)}>{t("common.cancel")}</Button><Button variant="primary" loading={openInv.isPending} disabled={reason.trim().length < 5} onClick={() => openInv.mutate(undefined)}>Open</Button></>}>
        <div className="stack"><p className="small muted">A staged action plan (re-test, NDT, cores) is generated from the failing evidence.</p><Field label="Reason" required hint="At least 5 characters"><Textarea value={reason} onChange={(e) => setReason(e.target.value)} /></Field><FormError error={openInv.error} /></div>
      </Modal>
    </div>
  );
}
