import type { NextRequest } from "next/server";
import { backendPath, errorResponse, forward } from "@/server/proxy";

type Ctx = { params: Promise<{ path: string[] }> };
async function handle(req: NextRequest, ctx: Ctx): Promise<Response> {
  const { path } = await ctx.params;
  const target = backendPath(path, req.nextUrl.search);
  if (!target) return errorResponse(404, "NOT_FOUND", "Not found");
  return forward(req, target);
}
export { handle as GET, handle as POST, handle as PATCH, handle as DELETE };
export const dynamic = "force-dynamic";
