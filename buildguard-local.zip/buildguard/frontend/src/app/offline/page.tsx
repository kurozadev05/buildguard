export default function Offline() {
  return (
    <main style={{ minHeight: "100dvh", display: "grid", placeItems: "center", padding: "1rem", textAlign: "center" }}>
      <div className="card stack" style={{ maxWidth: 420 }}>
        <h1>You&apos;re offline</h1>
        <p className="muted">This page isn&apos;t saved on your device yet. Pages you have already opened, and any changes you make, are still available. Reconnect to load new data.</p>
        {/* a plain link, not a JS button: this page must work even when no scripts could be loaded */}
        <a className="btn primary" href="">Try again</a>
      </div>
    </main>
  );
}
