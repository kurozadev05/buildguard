import { backendUrl } from "@/server/env";

export const dynamic = "force-dynamic";
/** Diagnostics for developers: is it the web server or the backend? Words only: no URLs, credentials or versions. */
export async function GET(): Promise<Response> {
  let backend = "unavailable"; let checks: unknown = null;
  try {
    const r = await fetch(`${backendUrl()}/ready`, { cache: "no-store", signal: AbortSignal.timeout(2500) });
    const j = await r.json().catch(() => null);
    backend = r.ok ? "ok" : "unavailable"; checks = j?.checks ?? null;
  } catch (e) { if (e instanceof Error && e.message.includes("BACKEND_URL")) backend = "not_configured"; }
  return Response.json({ web: "ok", backend, backend_checks: checks }, { status: backend === "ok" ? 200 : 503, headers: { "cache-control": "no-store" } });
}
