import type { NextRequest } from "next/server";
import { backendUrl } from "@/server/env";
import { clientIp, csrfProblem, errorResponse } from "@/server/proxy";
import { readCookies, setCookieHeaders, toTokens } from "@/server/session";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ action: string }> };

async function callBackend(path: string, init: RequestInit, req: NextRequest): Promise<Response | null> {
  try {
    return await fetch(`${backendUrl()}${path}`, { ...init, cache: "no-store", signal: AbortSignal.timeout(15_000),
      headers: { "content-type": "application/json", "x-forwarded-for": clientIp(req), "accept-language": req.headers.get("accept-language") ?? "en", ...(init.headers as Record<string, string>) } });
  } catch { return null; }
}

export async function POST(req: NextRequest, ctx: Ctx): Promise<Response> {
  const { action } = await ctx.params;
  const bad = csrfProblem(req);
  if (bad) return errorResponse(403, "CSRF_REFUSED", bad);

  if (action === "logout") {
    const { access, refresh } = readCookies(req);
    if (access) await callBackend("/api/auth/logout", { method: "POST", headers: { authorization: `Bearer ${access}` }, body: JSON.stringify({ refresh_token: refresh ?? null }) }, req);
    const h = new Headers({ "content-type": "application/json", "cache-control": "no-store" });
    setCookieHeaders(null).forEach((c) => h.append("set-cookie", c));
    return new Response(JSON.stringify({ success: true, data: { ok: true } }), { headers: h });
  }
  if (action !== "login" && action !== "register") return errorResponse(404, "NOT_FOUND", "Not found");

  const raw = await req.text();
  if (raw.length > 10_000) return errorResponse(413, "PAYLOAD_TOO_LARGE", "Request too large");
  const up = await callBackend(`/api/auth/${action}`, { method: "POST", body: raw }, req);
  if (!up) return errorResponse(502, "UPSTREAM_UNAVAILABLE", "The service is temporarily unavailable.");
  const body = await up.json().catch(() => null);
  const d = body?.data ?? body;
  const h = new Headers({ "content-type": "application/json", "cache-control": "no-store" });
  const rid = up.headers.get("x-request-id"); if (rid) h.set("x-request-id", rid);
  const ra = up.headers.get("retry-after"); if (ra) h.set("retry-after", ra);
  if (up.ok && d?.access_token) {
    setCookieHeaders(toTokens(d)).forEach((c) => h.append("set-cookie", c));
    return new Response(JSON.stringify({ success: true, data: { user: d.user } }), { status: up.status, headers: h }); // tokens are NOT forwarded to the browser
  }
  return new Response(JSON.stringify(body ?? { success: false, error: { code: "ERROR", message: "Request failed", details: [] } }), { status: up.status, headers: h });
}
