"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { AuthCard } from "@/components/AuthCard";
import { Field, Input, Select } from "@/components/ui/form";
import { Button, FormError } from "@/components/ui/ui";
import { friendly } from "@/lib/errors";
import { useT } from "@/lib/i18n";
import { confirmSession, postAuth } from "@/lib/auth-client";

export default function RegisterPage() {
  const { t, lang } = useT(); const router = useRouter();
  const [f, setF] = useState({ full_name: "", email: "", password: "", language: lang }); const [busy, setBusy] = useState(false); const [error, setError] = useState<unknown>(null); const [touched, setTouched] = useState(false);
  const errs = { full_name: f.full_name.trim().length < 2 ? "Enter your full name" : "", email: /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email) ? "" : "Enter a valid email address", password: f.password.length < 10 ? "Use at least 10 characters" : "" };
  const server = error ? friendly(error, t).fields : {};
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setTouched(true);
    if (Object.values(errs).some(Boolean)) return;
    setBusy(true); setError(null);
    try { await postAuth("register", { ...f, email: f.email.trim().toLowerCase() }); await confirmSession(); router.replace("/"); } catch (err) { setError(err); setBusy(false); }
  }
  return (
    <AuthCard title={t("login.register")}>
      <form onSubmit={submit} className="stack" noValidate>
        <Field label="Full name" required error={(touched && errs.full_name) || server.full_name}><Input autoComplete="name" value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></Field>
        <Field label={t("login.email")} required error={(touched && errs.email) || server.email}><Input type="email" autoComplete="email" inputMode="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        <Field label={t("login.password")} required hint="At least 10 characters" error={(touched && errs.password) || server.password}><Input type="password" autoComplete="new-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></Field>
        <Field label={t("common.language")}><Select value={f.language} onChange={(e) => setF({ ...f, language: e.target.value as "en" | "hi" })}><option value="en">English</option><option value="hi">हिन्दी</option></Select></Field>
        <FormError error={error} />
        <Button type="submit" variant="primary" loading={busy}>{t("login.register")}</Button>
      </form>
      <p className="small muted" style={{ margin: 0 }}>{t("login.haveAccount")} <Link href="/login">{t("common.signIn")}</Link></p>
    </AuthCard>
  );
}
