import type { NextRequest } from "next/server";
import { backendUrl } from "@/server/env";

export const dynamic = "force-dynamic";
/** Public QR passport pages are served by the backend (read-only, no login). This keeps QR URLs on the same public domain. */
export async function GET(req: NextRequest, ctx: { params: Promise<{ path: string[] }> }): Promise<Response> {
  const { path } = await ctx.params;
  if (path.some((s) => !/^[A-Za-z0-9_-]{4,64}$/.test(s))) return new Response("Not found", { status: 404 });
  try {
    const up = await fetch(`${backendUrl()}/p/${path.join("/")}`, { cache: "no-store", signal: AbortSignal.timeout(15_000), headers: { "accept-encoding": "identity", "x-forwarded-for": req.headers.get("x-forwarded-for") ?? "127.0.0.1" } });
    const h = new Headers({ "cache-control": "no-store" });
    for (const k of ["content-type", "content-security-policy", "x-content-type-options", "referrer-policy"]) { const v = up.headers.get(k); if (v) h.set(k, v); }
    return new Response(up.body, { status: up.status, headers: h });
  } catch { return new Response("Service unavailable", { status: 502 }); }
}
