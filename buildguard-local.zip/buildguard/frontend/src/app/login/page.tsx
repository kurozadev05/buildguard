"use client";
import { useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { AuthCard } from "@/components/AuthCard";
import { Field, Input } from "@/components/ui/form";
import { Alert, Button, FormError, SkeletonRows } from "@/components/ui/ui";
import { confirmSession, postAuth, safeNext } from "@/lib/auth-client";
import { useT } from "@/lib/i18n";

function LoginForm() {
  const { t } = useT(); const router = useRouter(); const qc = useQueryClient(); const sp = useSearchParams();
  const [email, setEmail] = useState(""); const [password, setPassword] = useState(""); const [busy, setBusy] = useState(false); const [error, setError] = useState<unknown>(null); const [touched, setTouched] = useState(false);
  const emailBad = touched && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email); const pwBad = touched && !password;
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setTouched(true);
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || !password) return;
    setBusy(true); setError(null);
    try { await postAuth("login", { email: email.trim().toLowerCase(), password }); await confirmSession(); qc.removeQueries(); router.replace(safeNext(sp.get("next"))); }
    catch (err) { setError(err); setBusy(false); }
  }
  return (
    <AuthCard title={t("login.title")}>
      {sp.get("reason") === "expired" && <Alert tone="warning">{t("err.auth")}</Alert>}
      <form onSubmit={submit} className="stack" noValidate>
        <Field label={t("login.email")} required error={emailBad ? "Enter a valid email address" : undefined}><Input type="email" autoComplete="username" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
        <Field label={t("login.password")} required error={pwBad ? "Enter your password" : undefined}><Input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
        <FormError error={error} />
        <Button type="submit" variant="primary" loading={busy}>{t("common.signIn")}</Button>
      </form>
      <p className="small muted" style={{ margin: 0 }}><Link href="/register">{t("login.register")}</Link></p>
    </AuthCard>
  );
}
export default function Page() { return <Suspense fallback={<SkeletonRows />}><LoginForm /></Suspense>; }
