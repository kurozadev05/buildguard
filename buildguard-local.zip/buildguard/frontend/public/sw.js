/* BUILDGUARD service worker.
 * Caches ONLY: hashed static assets, icons/manifest, the offline page, and page shells (HTML that contains no user data: the app renders data client-side).
 * NEVER caches: /bff/* (authenticated API), /auth/*, /p/* (public passports), or any non-GET request. AI answers and business data are therefore never stored by the worker.
 * Offline business data comes from the app's own per-user IndexedDB snapshots, which are wiped on sign-out. */
const VERSION = "__BUILD_ID__";   // replaced with the Next.js build id by scripts/postbuild.mjs: every build gets fresh caches, old ones are deleted on activate
const STATIC = `bg-static-${VERSION}`, PAGES = `bg-pages-${VERSION}`;
const PRECACHE = ["/offline", "/manifest.webmanifest", "/icons/icon-192.png", "/icons/icon-512.png"];
const MAX_PAGES = 30;

self.addEventListener("install", (e) => { e.waitUntil(caches.open(STATIC).then((c) => c.addAll(PRECACHE))); });   // no skipWaiting: the user chooses when to update
self.addEventListener("activate", (e) => {
  e.waitUntil((async () => { for (const k of await caches.keys()) if (![STATIC, PAGES].includes(k)) await caches.delete(k); await self.clients.claim(); })());
});
self.addEventListener("message", (e) => {
  if (e.data === "SKIP_WAITING") self.skipWaiting();
  if (e.data === "CLEAR_PAGES") e.waitUntil(caches.delete(PAGES));
  if (e.data && e.data.type === "WARM") e.waitUntil(warm(e.data.urls || []));
});

/* After sign-in the app asks us to prepare the core screens for offline use: fetch each page shell (with the user's cookie) and the
 * hashed JS/CSS it references, so the screens open AND become interactive with no network. Page shells hold no user data (data is loaded client-side). */
async function warm(urls) {
  const pages = await caches.open(PAGES), stat = await caches.open(STATIC);
  for (const u of urls) {
    try {
      const res = await fetch(u, { credentials: "same-origin", cache: "no-store" });
      if (!res.ok || res.redirected || new URL(res.url).pathname !== u.split("?")[0]) continue;      // not signed in / redirected to login: never cache that
      const html = await res.clone().text();
      await pages.put(u, res);
      for (const a of new Set(html.match(/\/_next\/static\/[^"'\\\s<>]+/g) || [])) {
        if (await stat.match(a)) continue;
        const r = await fetch(a).catch(() => null); if (r && r.ok) await stat.put(a, r);
      }
    } catch { /* offline or transient: try again next sign-in */ }
  }
  await trim(pages);
}

const NEVER = (u) => u.pathname.startsWith("/bff/") || u.pathname.startsWith("/auth/") || u.pathname.startsWith("/p/") || u.pathname.startsWith("/api/");
async function trim(cache) { const keys = await cache.keys(); for (let i = 0; i < keys.length - MAX_PAGES; i++) await cache.delete(keys[i]); }

self.addEventListener("fetch", (e) => {
  const req = e.request; const url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== self.location.origin || NEVER(url) || req.headers.has("range")) return;
  if (url.pathname.startsWith("/_next/static/") || url.pathname.startsWith("/icons/") || url.pathname === "/manifest.webmanifest") {
    e.respondWith(caches.open(STATIC).then(async (c) => { const hit = await c.match(req); if (hit) return hit; const res = await fetch(req); if (res.ok) c.put(req, res.clone()); return res; }));
    return;
  }
  if (req.mode === "navigate") {
    e.respondWith((async () => {
      try {
        const res = await fetch(req);
        if (res.ok && !res.redirected && res.type === "basic" && !["/login", "/register"].includes(url.pathname)) { const c = await caches.open(PAGES); await c.put(req, res.clone()); await trim(c); }
        return res;
      } catch {
        return (await caches.match(req, { cacheName: PAGES, ignoreSearch: true })) || (await caches.match("/offline", { cacheName: STATIC })) || new Response("Offline", { status: 503 });
      }
    })());
  }
});
