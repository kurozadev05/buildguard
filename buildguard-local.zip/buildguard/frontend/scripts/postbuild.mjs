// `output: "standalone"` builds a self-contained server but does NOT copy static assets or /public next to it.
// This makes `pnpm build` produce a directory that can be run (or copied into a container) as-is.
import { cpSync, existsSync, readFileSync, rmSync, writeFileSync } from "node:fs";
const out = ".next/standalone";
if (!existsSync(out)) { console.error("postbuild: .next/standalone missing: is output:'standalone' set?"); process.exit(1); }
rmSync(`${out}/.next/static`, { recursive: true, force: true }); rmSync(`${out}/public`, { recursive: true, force: true });
cpSync(".next/static", `${out}/.next/static`, { recursive: true }); cpSync("public", `${out}/public`, { recursive: true });
// Stamp the service worker with this build's id: a new build => new worker bytes => the browser offers the update => old caches are removed.
const buildId = readFileSync(".next/BUILD_ID", "utf8").trim().replace(/[^A-Za-z0-9_-]/g, "");
const swPath = `${out}/public/sw.js`;
writeFileSync(swPath, readFileSync(swPath, "utf8").replace("__BUILD_ID__", buildId));
console.log(`postbuild: copied .next/static and public into .next/standalone; service worker stamped with build ${buildId}`);
